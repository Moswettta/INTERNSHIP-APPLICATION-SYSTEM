<?php
session_start();

// Include database connection initialization
require_once $_SERVER['DOCUMENT_ROOT'] . '/internship/init.php';

// Initialize variables to hold form input values
$category = $postedOn = $applyBy = $nameOfCompany = $aboutCompany = $aboutInternship = $location = $perks = $duration = $stipend = $positions = $whoCanApply = $featured = '';

// Function to sanitize input data
function sanitize($input) {
    global $db;
    return mysqli_real_escape_string($db, trim($input));
}

// Check if form submitted via POST method
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and validate input data
    $category = sanitize($_POST['category']);
    $postedOn = sanitize($_POST['postedOn']);
    $applyBy = sanitize($_POST['applyBy']);
    $nameOfCompany = sanitize($_POST['nameOfCompany']);
    $aboutCompany = sanitize($_POST['aboutCompany']);
    $aboutInternship = sanitize($_POST['aboutInternship']);
    $location = sanitize($_POST['location']);
    $perks = sanitize($_POST['perks']);
    $duration = (int) $_POST['duration'];
    $stipend = (int) $_POST['stipend'];
    $positions = (int) $_POST['positions'];
    $whoCanApply = sanitize($_POST['whoCanApply']);
    $featured = (int) $_POST['featured'];

    // Insert into database
    $insertQuery = "INSERT INTO internships (emp_id, category, postedOn, applyBy, nameOfCompany, aboutCompany, aboutInternship, location, perks, duration, stipend, positions, whoCanApply, featured)
                    VALUES (1, '$category', '$postedOn', '$applyBy', '$nameOfCompany', '$aboutCompany', '$aboutInternship', '$location', '$perks', $duration, $stipend, $positions, '$whoCanApply', $featured)";

    $result = $db->query($insertQuery);
    
    if ($result) {
        $_SESSION['success_flash'] = 'Internship added successfully!';
        header('Location: internships.php'); // Redirect to internships listing page or wherever desired
        exit();
    } else {
        $_SESSION['error_flash'] = 'Failed to add internship. Please try again.';
        // Handle error as needed, maybe log it
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Internship</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Add Internship</h2>
        <!-- Display error messages if any -->
        <?php if (isset($_SESSION['error_flash'])) : ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $_SESSION['error_flash']; ?>
            </div>
            <?php unset($_SESSION['error_flash']); ?>
        <?php endif; ?>

        <form method="post">
            <div class="form-group">
                <label for="category">Category:</label>
                <input type="text" class="form-control" id="category" name="category" required>
            </div>
            <div class="form-group">
                <label for="postedOn">Posted On:</label>
                <input type="date" class="form-control" id="postedOn" name="postedOn" required>
            </div>
            <div class="form-group">
                <label for="applyBy">Apply By:</label>
                <input type="date" class="form-control" id="applyBy" name="applyBy" required>
            </div>
            <div class="form-group">
                <label for="nameOfCompany">Name of Company:</label>
                <input type="text" class="form-control" id="nameOfCompany" name="nameOfCompany" required>
            </div>
            <div class="form-group">
                <label for="aboutCompany">About Company:</label>
                <textarea class="form-control" id="aboutCompany" name="aboutCompany" rows="3" required></textarea>
            </div>
            <div class="form-group">
                <label for="aboutInternship">About Internship:</label>
                <textarea class="form-control" id="aboutInternship" name="aboutInternship" rows="3" required></textarea>
            </div>
            <div class="form-group">
                <label for="location">Location:</label>
                <input type="text" class="form-control" id="location" name="location" required>
            </div>
            <div class="form-group">
                <label for="perks">Perks:</label>
                <textarea class="form-control" id="perks" name="perks" rows="3" required></textarea>
            </div>
            <div class="form-group">
                <label for="duration">Duration (in months):</label>
                <input type="number" class="form-control" id="duration" name="duration" required>
            </div>
            <div class="form-group">
                <label for="stipend">Stipend:</label>
                <input type="number" class="form-control" id="stipend" name="stipend" required>
            </div>
            <div class="form-group">
                <label for="positions">Positions Available:</label>
                <input type="number" class="form-control" id="positions" name="positions" required>
            </div>
            <div class="form-group">
                <label for="whoCanApply">Who Can Apply:</label>
                <textarea class="form-control" id="whoCanApply" name="whoCanApply" rows="3" required></textarea>
            </div>
            <div class="form-group">
                <label for="featured">Featured (1 for Yes, 0 for No):</label>
                <input type="number" class="form-control" id="featured" name="featured" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</body>
</html>
