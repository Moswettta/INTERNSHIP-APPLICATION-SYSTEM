<?php
session_start();

// Include database connection
include 'config.php';

// Initialize variables
$nameOfCompany = $aboutCompany = $email = $password = $address1 = $address2 = $city = $state = $zipcode = $phone = $country = "";
$nameOfCompanyErr = $aboutCompanyErr = $emailErr = $passwordErr = $address1Err = $cityErr = $stateErr = $zipcodeErr = $phoneErr = $countryErr = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate inputs
    if (empty($_POST["nameOfCompany"])) {
        $nameOfCompanyErr = "Name of Company is required";
    } else {
        $nameOfCompany = $_POST["nameOfCompany"];
    }

    if (empty($_POST["aboutCompany"])) {
        $aboutCompanyErr = "About Company is required";
    } else {
        $aboutCompany = $_POST["aboutCompany"];
    }

    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
    } else {
        $email = $_POST["email"];
        // Check if email is valid
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
        }
    }

    if (empty($_POST["password"])) {
        $passwordErr = "Password is required";
    } else {
        $password = password_hash($_POST["password"], PASSWORD_DEFAULT); // Hash the password
    }

    if (empty($_POST["address1"])) {
        $address1Err = "Address is required";
    } else {
        $address1 = $_POST["address1"];
    }

    $address2 = $_POST["address2"]; // Optional

    if (empty($_POST["city"])) {
        $cityErr = "City is required";
    } else {
        $city = $_POST["city"];
    }

    if (empty($_POST["state"])) {
        $stateErr = "State is required";
    } else {
        $state = $_POST["state"];
    }

    if (empty($_POST["zipcode"])) {
        $zipcodeErr = "Zipcode is required";
    } else {
        $zipcode = $_POST["zipcode"];
    }

    if (empty($_POST["phone"])) {
        $phoneErr = "Phone number is required";
    } else {
        $phone = $_POST["phone"];
    }

    if (empty($_POST["country"])) {
        $countryErr = "Country is required";
    } else {
        $country = $_POST["country"];
    }

    // Check for errors before inserting into database
    if (empty($nameOfCompanyErr) && empty($aboutCompanyErr) && empty($emailErr) && empty($passwordErr) && empty($address1Err) && empty($cityErr) && empty($stateErr) && empty($zipcodeErr) && empty($phoneErr) && empty($countryErr)) {
        // Check if the company already exists
        $sql_check = "SELECT * FROM employer WHERE nameOfCompany = '$nameOfCompany'";
        $result_check = $db->query($sql_check);
        
        if ($result_check->num_rows > 0) {
            $errorMsg = "Error: This company already exists!";
        } else {
            // Insert employer into database
            $sql = "INSERT INTO employer (nameOfCompany, aboutCompany, email, password, address1, address2, city, state, zipcode, phone, country, ip) VALUES ('$nameOfCompany', '$aboutCompany', '$email', '$password', '$address1', '$address2', '$city', '$state', '$zipcode', '$phone', '$country', '$_SERVER[REMOTE_ADDR]')";

            if ($db->query($sql) === TRUE) {
                $successMsg = "New employer added successfully!";
            } else {
                $errorMsg = "Error: " . $sql . "<br>" . $db->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Employer</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .black-sidebar {
            background-color: #000;
            color: #fff;
            height: 100vh; /* Full height */
        }
        .black-sidebar a {
            color: #fff; /* Links in sidebar */
        }
    </style>
</head>
<body>
    <?php include('includes/header.php'); ?>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 black-sidebar">
                <?php include('includes/sidebar.php'); ?>
            </div>
            <!-- Main Content -->
<div class="col-md-6">
    <h2>Add Employer</h2>
    <?php if (!empty($successMsg)) echo "<div class='alert alert-success'>$successMsg</div>"; ?>
    <?php if (!empty($errorMsg)) echo "<div class='alert alert-danger'>$errorMsg</div>"; ?>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <div class="form-group">
            <label for="nameOfCompany">Name of Company</label>
            <input type="text" class="form-control" id="nameOfCompany" name="nameOfCompany" value="<?php echo $nameOfCompany;?>">
            <span class="text-danger"><?php echo $nameOfCompanyErr;?></span>
        </div>
        <div class="form-group">
            <label for="aboutCompany">About Company</label>
            <textarea class="form-control" id="aboutCompany" name="aboutCompany"><?php echo $aboutCompany;?></textarea>
            <span class="text-danger"><?php echo $aboutCompanyErr;?></span>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo $email;?>">
            <span class="text-danger"><?php echo $emailErr;?></span>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password">
            <span class="text-danger"><?php echo $passwordErr;?></span>
        </div>
        <div class="form-group">
            <label for="address1">Address 1</label>
            <input type="text" class="form-control" id="address1" name="address1" value="<?php echo $address1;?>">
            <span class="text-danger"><?php echo $address1Err;?></span>
        </div>
        <div class="form-group">
            <label for="address2">Address 2 (optional)</label>
            <input type="text" class="form-control" id="address2" name="address2" value="<?php echo $address2;?>">
        </div>
        <div class="form-group">
            <label for="city">City</label>
            <input type="text" class="form-control" id="city" name="city" value="<?php echo $city;?>">
            <span class="text-danger"><?php echo $cityErr;?></span>
        </div>
        <div class="form-group">
            <label for="state">State</label>
            <input type="text" class="form-control" id="state" name="state" value="<?php echo $state;?>">
            <span class="text-danger"><?php echo $stateErr;?></span>
        </div>
        <div class="form-group">
            <label for="zipcode">Zipcode</label>
            <input type="text" class="form-control" id="zipcode" name="zipcode" value="<?php echo $zipcode;?>">
            <span class="text-danger"><?php echo $zipcodeErr;?></span>
        </div>
        <div class="form-group">
            <label for="phone">Phone</label>
            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo $phone;?>">
            <span class="text-danger"><?php echo $phoneErr;?></span>
        </div>
        <div class="form-group">
            <label for="country">Country</label>
            <input type="text" class="form-control" id="country" name="country" value="<?php echo $country;?>">
            <span class="text-danger"><?php echo $countryErr;?></span>
        </div>
        <button type="submit" class="btn btn-primary">Add Employer</button>
    </form>
</div>

</html>
