<?php
session_start();

// Include database connection
include 'config.php';

// Function to count records
function countRecords($table) {
    global $db;
    $sql = "SELECT COUNT(*) AS count FROM $table";
    $result = $db->query($sql);
    if ($result) {
        $row = $result->fetch_assoc();
        return $row['count'];
    } else {
        die("Database query failed: " . $db->error);
    }
}

// Count the number of employers, students, and internships
$numEmployers = countRecords('employer');
$numStudents = countRecords('student');
$numInternships = countRecords('internships');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .black-sidebar {
            background-color: #000;
            color: #fff;
            height: 100vh; /* Full height */
        }
        .black-sidebar a {
            color: #fff; /* Links in sidebar */
        }
        .card-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .card {
            flex: 1;
            margin: 10px;
        }
    </style>
</head>
<body>
    <?php include('includes/header.php'); ?>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 black-sidebar">
                <?php include('includes/sidebar.php'); ?>
            </div>
            <!-- Main Content -->
            <div class="col-md-9">
                <div class="card-container">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Number of Employers</h5>
                            <p class="card-text"><?php echo $numEmployers; ?></p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Number of Students</h5>
                            <p class="card-text"><?php echo $numStudents; ?></p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Number of Internships</h5>
                            <p class="card-text"><?php echo $numInternships; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
