<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// Database connection settings
$db_host = 'localhost';
$db_user = 'root';
$db_password = '';
$db_name = 'internship';

// Create connection
$db = new mysqli($db_host, $db_user, $db_password, $db_name);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employer Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: Arial, sans-serif;
        }
        .sidebar {
            width: 250px;
            background: #343a40;
            color: #fff;
            padding: 15px;
            height: 100%;
            position: fixed;
        }
        .sidebar h2 {
            margin-bottom: 20px;
        }
        .sidebar a {
            color: #fff;
            text-decoration: none;
            display: block;
            padding: 10px 0;
            transition: background 0.3s ease;
        }
        .sidebar a:hover {
            background: #495057;
        }
        .main-content {
            margin-left: 250px; /* Same width as the sidebar */
            padding: 20px;
        }
        .card {
            margin-bottom: 20px;
        }
        .card-title {
            margin-bottom: 10px;
            font-size: 20px;
        }
        .card-text {
            font-size: 24px;
            color: #007bff;
            font-weight: bold;
        }
        .internships {
            margin-top: 20px;
        }
        .internship-card {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<?php


// Include database connection
include 'config.php';

// Function to count records
function countRecords($table) {
    global $db;
    $sql = "SELECT COUNT(*) AS count FROM $table";
    $result = $db->query($sql);
    if ($result) {
        $row = $result->fetch_assoc();
        return $row['count'];
    } else {
        die("Database query failed: " . $db->error);
    }
}

// Count the number of employers, students, and internships
$numEmployers = countRecords('employer');
$numStudents = countRecords('student');
$numInternships = countRecords('internships');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .black-sidebar {
            background-color: #000;
            color: #fff;
            height: 100vh; /* Full height */
        }
        .black-sidebar a {
            color: #fff; /* Links in sidebar */
        }
        .card-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .card {
            flex: 1;
            margin: 10px;
        }
    </style>
</head>
<body>
    <?php include('includes/header.php'); ?>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 black-sidebar">
                <?php include('includes/sidebar.php'); ?>
            </div>
            <!-- Main Content -->
            <div class="col-md-9">
                <div class="card-container">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Number of Employers</h5>
                            <p class="card-text"><?php echo $numEmployers; ?></p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Number of Students</h5>
                            <p class="card-text"><?php echo $numStudents; ?></p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Number of Internships</h5>
                            <p class="card-text"><?php echo $numInternships; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<!-- Bootstrap JS, Popper.js, and jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
