<?php
session_start();

// Include database connection initialization
require_once $_SERVER['DOCUMENT_ROOT'] . '/internship/init.php';

// Function to sanitize input data
function sanitize($input) {
    global $db;
    return mysqli_real_escape_string($db, trim($input));
}

// Check if internship ID is provided in the URL
if (isset($_GET['internship_id'])) {
    $internship_id = sanitize($_GET['internship_id']);

    // Fetch internship details from the database
    $query = "SELECT * FROM internships WHERE id = $internship_id";
    $result = $db->query($query);

    if ($result->num_rows > 0) {
        $internship = $result->fetch_assoc();
    } else {
        $_SESSION['error_flash'] = 'Internship not found.';
        header('Location: internships.php'); // Redirect if internship not found
        exit();
    }

    // Fetch applications for this internship
    $query = "SELECT * FROM applications WHERE internship_id = $internship_id";
    $result = $db->query($query);

    if ($result->num_rows > 0) {
        $applications = $result->fetch_all(MYSQLI_ASSOC);
    } else {
        $applications = [];
    }
} else {
    $_SESSION['error_flash'] = 'Internship ID not provided.';
    header('Location: internships.php'); // Redirect if internship ID not provided
    exit();
}

// Handle approve or reject actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['approve'])) {
        $application_id = sanitize($_POST['approve']);

        // Update application status to approved
        $updateQuery = "UPDATE applications SET status = 'approved' WHERE id = $application_id";
        $result = $db->query($updateQuery);

        if ($result) {
            $_SESSION['success_flash'] = 'Application approved successfully!';
        } else {
            $_SESSION['error_flash'] = 'Failed to approve application. Please try again.';
        }
    } elseif (isset($_POST['reject'])) {
        $application_id = sanitize($_POST['reject']);

        // Update application status to rejected
        $updateQuery = "UPDATE applications SET status = 'rejected' WHERE id = $application_id";
        $result = $db->query($updateQuery);

        if ($result) {
            $_SESSION['success_flash'] = 'Application rejected successfully!';
        } else {
            $_SESSION['error_flash'] = 'Failed to reject application. Please try again.';
        }
    }

    // Redirect to avoid form resubmission on refresh
    header("Location: view_applications.php?internship_id=$internship_id");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Applications for <?php echo $internship['nameOfCompany']; ?></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Applications for <?php echo $internship['nameOfCompany']; ?> Internship</h2>
        
        <!-- Display success or error messages if any -->
        <?php if (isset($_SESSION['success_flash'])) : ?>
            <div class="alert alert-success" role="alert">
                <?php echo $_SESSION['success_flash']; ?>
            </div>
            <?php unset($_SESSION['success_flash']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_flash'])) : ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $_SESSION['error_flash']; ?>
            </div>
            <?php unset($_SESSION['error_flash']); ?>
        <?php endif; ?>

        <!-- Display internship details -->
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Internship Details</h5>
                <p><strong>Name of Company:</strong> <?php echo $internship['nameOfCompany']; ?></p>
                <p><strong>Category:</strong> <?php echo $internship['category']; ?></p>
                <p><strong>Posted On:</strong> <?php echo $internship['postedOn']; ?></p>
                <p><strong>Apply By:</strong> <?php echo $internship['applyBy']; ?></p>
                <p><strong>Location:</strong> <?php echo $internship['location']; ?></p>
                <p><strong>About Company:</strong><br><?php echo $internship['aboutCompany']; ?></p>
                <p><strong>About Internship:</strong><br><?php echo $internship['aboutInternship']; ?></p>
                <p><strong>Perks:</strong> <?php echo $internship['perks']; ?></p>
                <p><strong>Duration:</strong> <?php echo $internship['duration']; ?> months</p>
                <p><strong>Stipend:</strong> <?php echo $internship['stipend']; ?></p>
                <p><strong>Positions:</strong> <?php echo $internship['positions']; ?></p>
                <p><strong>Who Can Apply:</strong><br><?php echo $internship['whoCanApply']; ?></p>
                <p><strong>Featured:</strong> <?php echo $internship['featured'] ? 'Yes' : 'No'; ?></p>
            </div>
        </div>

        <!-- Display applications table -->
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Resume</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($applications as $application) : ?>
                    <tr>
                        <td><?php echo $application['id']; ?></td>
                        <td><?php echo $application['name']; ?></td>
                        <td><?php echo $application['email']; ?></td>
                        <td><?php echo $application['phone']; ?></td>
                        <td><?php echo $application['resume']; ?></td>
                        <td><?php echo ucfirst($application['status']); ?></td>
                        <td>
                            <form method="post">
                                <button type="submit" class="btn btn-sm btn-success" name="approve" value="<?php echo $application['id']; ?>">Approve</button>
                                <button type="submit" class="btn btn-sm btn-danger" name="reject" value="<?php echo $application['id']; ?>">Reject</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
