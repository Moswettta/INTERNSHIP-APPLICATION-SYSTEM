<?php
session_start();

// Include database connection
include 'config.php';

// Initialize variables
$dateFilter = '';
$monthFilter = '';
$yearFilter = '';

// Handle filter form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!empty($_POST['date'])) {
        $dateFilter = $_POST['date'];
        $sql = "SELECT applications.id, applications.applied, applications.status, internships.nameOfCompany, internships.aboutInternship, internships.location, student.fullname 
                FROM applications 
                JOIN internships ON applications.int_id = internships.id 
                JOIN student ON applications.stu_id = student.stu_id
                WHERE DATE(applications.applied) = '$dateFilter'";
    } elseif (!empty($_POST['month'])) {
        $monthFilter = $_POST['month'];
        $sql = "SELECT applications.id, applications.applied, applications.status, internships.nameOfCompany, internships.aboutInternship, internships.location, student.fullname 
                FROM applications 
                JOIN internships ON applications.int_id = internships.id 
                JOIN student ON applications.stu_id = student.stu_id
                WHERE MONTH(applications.applied) = '$monthFilter'";
    } elseif (!empty($_POST['year'])) {
        $yearFilter = $_POST['year'];
        $sql = "SELECT applications.id, applications.applied, applications.status, internships.nameOfCompany, internships.aboutInternship, internships.location, student.fullname 
                FROM applications 
                JOIN internships ON applications.int_id = internships.id 
                JOIN student ON applications.stu_id = student.stu_id
                WHERE YEAR(applications.applied) = '$yearFilter'";
    } else {
        $sql = "SELECT applications.id, applications.applied, applications.status, internships.nameOfCompany, internships.aboutInternship, internships.location, student.fullname 
                FROM applications 
                JOIN internships ON applications.int_id = internships.id 
                JOIN student ON applications.stu_id = student.stu_id";
    }
} else {
    $sql = "SELECT applications.id, applications.applied, applications.status, internships.nameOfCompany, internships.aboutInternship, internships.location, student.fullname 
            FROM applications 
            JOIN internships ON applications.int_id = internships.id 
            JOIN student ON applications.stu_id = student.stu_id";
}

$result = $db->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Internship Report</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .black-sidebar {
            background-color: #000;
            color: #fff;
            height: 100vh; /* Full height */
        }
        .black-sidebar a {
            color: #fff; /* Links in sidebar */
        }
    </style>
</head>
<body>
    <?php include('includes/header.php'); ?>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 black-sidebar">
                <?php include('includes/sidebar.php'); ?>
            </div>
            <!-- Main Content -->
            <div class="col-md-9">
                <h2>Internship Application Report</h2>
                <form method="post" class="mb-4">
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="date">Date</label>
                            <input type="date" class="form-control" id="date" name="date">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="month">Month</label>
                            <input type="number" class="form-control" id="month" name="month" placeholder="Month (1-12)">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="year">Year</label>
                            <input type="number" class="form-control" id="year" name="year" placeholder="Year (e.g., 2023)">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Filter</button>
                </form>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Applied Date</th>
                            <th>Status</th>
                            <th>Student Name</th>
                            <th>Company</th>
                            <th>Internship Description</th>
                            <th>Location</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                echo "<tr>
                                        <td>{$row['id']}</td>
                                        <td>{$row['applied']}</td>
                                        <td>{$row['status']}</td>
                                        <td>{$row['fullname']}</td>
                                        <td>{$row['nameOfCompany']}</td>
                                        <td>{$row['aboutInternship']}</td>
                                        <td>{$row['location']}</td>
                                      </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7'>No applications found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
