<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa; /* Light grey background */
            font-family: Arial, sans-serif;
        }

        .card {
            max-width: 400px;
            margin: auto;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #007bff; /* Primary color for header */
            color: #fff; /* Text color for header */
            text-align: center;
            padding-top: 10px;
            padding-bottom: 10px;
        }

        .card-body {
            padding: 20px;
        }

        .form-control {
            border-color: #d1d3e2; /* Light grey border for input fields */
        }

        .btn-primary {
            background-color: #1c2a48; /* Dark blue background for button */
            border-color: #1c2a48; /* Dark blue border for button */
        }

        .btn-primary:hover {
            background-color: #0d1630; /* Darken button on hover */
            border-color: #0d1630;
        }

        .alert {
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h3 class="h3-responsive">Login</h3>
            </div>
            <div class="card-body">
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <div class="md-form form-sm">
                        <label for="email" style="color: #495057;">Email</label>
                        <input type="text" id="email" class="form-control form-control-sm" name="email" required>
                        
                    </div>
                    <div class="md-form form-sm">
                        <label for="password" style="color: #495057;">Password</label>
                        <input type="password" id="password" class="form-control form-control-sm" name="password" required>                        
                    </div><br><br>
                    <div class="text-center">
                        <button type="submit" name="login" class="btn btn-primary">Login</button><br><br>
                    </div>
                     <div class="text-center">
                      <div class="container mt-5">
        <a href="/internship/index.php" class="btn btn-primary">Home</a>
    </div>

                    </div>
                </form>
            </div>
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
                include 'config.php';

                // Sanitize user inputs
                $email = mysqli_real_escape_string($db, $_POST['email']);
                $password = mysqli_real_escape_string($db, $_POST['password']);

                // Retrieve user from database
                $query = "SELECT * FROM users WHERE email = '$email'";
                $result = mysqli_query($db, $query);

                if ($result && mysqli_num_rows($result) > 0) {
                    $user = mysqli_fetch_assoc($result);
                    if (password_verify($password, $user['password'])) {
                        // Passwords match, set session variables
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['email'] = $user['email'];
                        $_SESSION['full_name'] = $user['full_name'];
                        $_SESSION['permission'] = $user['permission'];

                        // Update last login timestamp
                        $update_last_login = "UPDATE users SET last_login = NOW() WHERE id = " . $user['id'];
                        mysqli_query($db, $update_last_login);

                        // Redirect to desired page after login
                        header("Location: index.php");
                        exit();
                    } else {
                        echo "<div class='alert alert-danger mt-3'>Incorrect email or password!</div>";
                    }
                } else {
                    echo "<div class='alert alert-danger mt-3'>User not found!</div>";
                }
            }
            ?>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
