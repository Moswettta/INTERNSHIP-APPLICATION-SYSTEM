<?php include 'header.php'; ?>

<div class="card">
    <div class="card-header">
        <h3 class="p-2 h3-responsive">Register here!</h3>
    </div>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div class="card-body">
            <div class="md-form form-sm">
                <input type="text" id="full_name" class="form-control form-control-sm" name="full_name" required>
                <label for="full_name">Full Name</label>
            </div>
            <div class="md-form form-sm">
                <input type="email" id="email" class="form-control form-control-sm" name="email" required>
                <label for="email">Email</label>
            </div>
            <div class="md-form form-sm">
                <input type="password" id="password" class="form-control form-control-sm" name="password" required>
                <label for="password">Password</label>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" name="register" class="btn btn-primary">Register</button>
        </div>
    </form>
</div>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    include 'config.php';

    // Sanitize user inputs
    $full_name = mysqli_real_escape_string($db, $_POST['full_name']);
    $email = mysqli_real_escape_string($db, $_POST['email']);
    $password = mysqli_real_escape_string($db, $_POST['password']);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hash password for security

    // Check if email exists
    $check_query = "SELECT * FROM users WHERE email = '$email'";
    $check_result = mysqli_query($db, $check_query);
    if (mysqli_num_rows($check_result) > 0) {
        echo "<div class='alert alert-danger'>Email already exists! Please choose a different email.</div>";
    } else {
        // Insert user into database
        $insert_query = "INSERT INTO users (full_name, email, password, permission, join_date, last_login) 
                         VALUES ('$full_name', '$email', '$hashed_password', 'user', NOW(), NOW())";
        
        if (mysqli_query($db, $insert_query)) {
            $_SESSION['message'] = "Registration successful! Please log in.";
            header("Location: login.php");
            exit();
        } else {
            echo "<div class='alert alert-danger'>Registration failed: " . mysqli_error($db) . "</div>";
        }
    }
}
?>

<?php include 'footer.php'; ?>
