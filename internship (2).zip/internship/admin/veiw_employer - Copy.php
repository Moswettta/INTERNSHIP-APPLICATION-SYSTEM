<?php
session_start();

// Include database connection
include 'config.php';

// Function to fetch all employers
function getAllEmployers() {
    global $db;
    $sql = "SELECT * FROM employer";
    $result = $db->query($sql);
    if ($result) {
        return $result->fetch_all(MYSQLI_ASSOC);
    } else {
        die("Database query failed: " . $db->error);
    }
}

// Function to delete an employer
if (isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];
    // Delete employer
    $delete_sql = "DELETE FROM employer WHERE id = $delete_id";
    if ($db->query($delete_sql) === TRUE) {
        $successMsg = "Employer deleted successfully!";
    } else {
        $errorMsg = "Error deleting employer: " . $db->error;
    }
}

// Fetch all employers
$employers = getAllEmployers();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Employers</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .black-sidebar {
            background-color: #000;
            color: #fff;
            height: 100vh; /* Full height */
        }
        .black-sidebar a {
            color: #fff; /* Links in sidebar */
        }
        .card-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .card {
            flex: 1;
            margin: 10px;
        }
        .table-container {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <?php include('includes/header.php'); ?>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 black-sidebar">
                <?php include('includes/sidebar.php'); ?>
            </div>
            <div class="col-md-9">
                <div class="table-container">
                    <h3>All Employers</h3>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name of Company</th>
                                <th>Email</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($employers as $employer) { ?>
                                <tr>
                                    <td><?php echo $employer['id']; ?></td>
                                    <td><?php echo $employer['nameOfCompany']; ?></td>
                                    <td><?php echo $employer['email']; ?></td>
                                    <td>
                                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                            <input type="hidden" name="delete_id" value="<?php echo $employer['id']; ?>">
                                            <button type="submit" class="btn btn-danger">DELETE</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
