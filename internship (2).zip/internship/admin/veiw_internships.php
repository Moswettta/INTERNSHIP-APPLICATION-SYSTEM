<?php
session_start();

// Include database connection
include 'config.php';

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    
    // Delete internship
    $delete_sql = "DELETE FROM internships WHERE id = $delete_id";
    if ($db->query($delete_sql) === TRUE) {
        $successMsg = "Internship deleted successfully!";
    } else {
        $errorMsg = "Error deleting internship: " . $db->error;
    }
}

// Fetch internships data
$sql = "SELECT * FROM internships";
$result = $db->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Internships</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .black-sidebar {
            background-color: #000;
            color: #fff;
            height: 100vh; /* Full height */
        }
        .black-sidebar a {
            color: #fff; /* Links in sidebar */
        }
    </style>
    <script>
        function confirmDelete() {
            return confirm("Are you sure you want to delete this internship position?");
        }
    </script>
</head>
<body>
    <?php include('includes/header.php'); ?>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 black-sidebar">
                <?php include('includes/sidebar.php'); ?>
            </div>
            <!-- Main Content -->
            <div class="col-md-9">
                <h2>View Internships</h2>
                <?php if (!empty($successMsg)) echo "<div class='alert alert-success'>$successMsg</div>"; ?>
                <?php if (!empty($errorMsg)) echo "<div class='alert alert-danger'>$errorMsg</div>"; ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Company</th>
                            <th>Category</th>
                            <th>Location</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result && $result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                echo '<tr>';
                                echo '<td>' . $row['id'] . '</td>';
                                echo '<td>' . $row['nameOfCompany'] . '</td>';
                                echo '<td>' . $row['category'] . '</td>';
                                echo '<td>' . $row['location'] . '</td>';
                                echo '<td><a href="?delete_id=' . $row['id'] . '" class="btn btn-danger" onclick="return confirmDelete()">DELETE</a></td>';
                                echo '</tr>';
                            }
                        } else {
                            echo "<tr><td colspan='5'>No internships found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
