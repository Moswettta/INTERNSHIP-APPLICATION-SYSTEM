<?php
session_start();

// Include database connection
include 'config.php';

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    // Delete student
    $delete_sql = "DELETE FROM student WHERE stu_id = $delete_id";
    if ($db->query($delete_sql) === TRUE) {
        $successMsg = "Student deleted successfully!";
    } else {
        $errorMsg = "Error deleting student: " . $db->error;
    }
}

// Fetch students and their applications
$sql = "SELECT student.stu_id, student.fullname, student.email, GROUP_CONCAT(CONCAT(internships.nameOfCompany, ', ', internships.category, ', ', internships.location) SEPARATOR '<br>') AS internships
        FROM student 
        LEFT JOIN applications ON student.stu_id = applications.stu_id
        LEFT JOIN internships ON applications.int_id = internships.id
        GROUP BY student.stu_id
        ORDER BY student.stu_id";
$result = $db->query($sql);

// Error handling for query execution
if (!$result) {
    $errorMsg = "Query failed: " . $db->error;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Students</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .black-sidebar {
            background-color: #000;
            color: #fff;
            height: 100vh; /* Full height */
        }
        .black-sidebar a {
            color: #fff; /* Links in sidebar */
        }
    </style>
</head>
<body>
    <?php include('includes/header.php'); ?>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 black-sidebar">
                <?php include('includes/sidebar.php'); ?>
            </div>
            <!-- Main Content -->
            <div class="col-md-9">
                <h2>View Students</h2>
                <?php if (!empty($successMsg)) echo "<div class='alert alert-success'>$successMsg</div>"; ?>
                <?php if (!empty($errorMsg)) echo "<div class='alert alert-danger'>$errorMsg</div>"; ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Applied Internships</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result && $result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                echo '<tr>';
                                echo '<td>' . $row['stu_id'] . '</td>';
                                echo '<td>' . $row['fullname'] . '</td>';
                                echo '<td>' . $row['email'] . '</td>';
                                echo '<td>' . $row['internships'] . '</td>';
                                echo '<td><a href="?delete_id=' . $row['stu_id'] . '" class="btn btn-danger">DELETE</a></td>';
                                echo '</tr>';
                            }
                        } else {
                            echo "<tr><td colspan='5'>No students found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
