<?php
    // Define BASEURL constant
    define('BASEURL', 'http://localhost/internship/'); // Adjust the URL according to your environment

    // Other initialization code goes here...
?>
