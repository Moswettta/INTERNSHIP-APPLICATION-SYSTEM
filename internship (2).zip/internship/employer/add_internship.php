<?php
session_start();
include 'config.php'; // Adjust the path as necessary

// Check if the employer is logged in
if (!isset($_SESSION['employer_id'])) {
    header("Location: login_register.php");
    exit();
}

// Initialize variables and set to empty values
$category = $postedOn = $applyBy = $nameOfCompany = $aboutCompany = $aboutInternship = $location = $perks = $duration = $stipend = $positions = $whoCanApply = "";
$featured = $deleted = 0;
$emp_id = $_SESSION['employer_id'];

// Fetch employer's details to pre-fill company name and about fields
$sql = "SELECT nameOfCompany, aboutCompany FROM employer WHERE id = ?";
$stmt = $db->prepare($sql);
$stmt->bind_param("i", $emp_id);
$stmt->execute();
$result = $stmt->get_result();
$employer = $result->fetch_assoc();

if ($employer) {
    $nameOfCompany = $employer['nameOfCompany'];
    $aboutCompany = $employer['aboutCompany'];
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category = $_POST['category'];
    $postedOn = $_POST['postedOn'];
    $applyBy = $_POST['applyBy'];
    $nameOfCompany = $_POST['nameOfCompany'];
    $aboutCompany = $_POST['aboutCompany'];
    $aboutInternship = $_POST['aboutInternship'];
    $location = $_POST['location'];
    $perks = $_POST['perks'];
    $duration = $_POST['duration'];
    $stipend = $_POST['stipend'];
    $positions = $_POST['positions'];
    $whoCanApply = $_POST['whoCanApply'];
    $featured = isset($_POST['featured']) ? 1 : 0;
    $deleted = isset($_POST['deleted']) ? 1 : 0;

    $sql = "INSERT INTO internships (emp_id, category, postedOn, applyBy, nameOfCompany, aboutCompany, aboutInternship, location, perks, duration, stipend, positions, whoCanApply, featured, deleted) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("issssssssiiiiii", $emp_id, $category, $postedOn, $applyBy, $nameOfCompany, $aboutCompany, $aboutInternship, $location, $perks, $duration, $stipend, $positions, $whoCanApply, $featured, $deleted);
    
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "New internship added successfully";
        header("Location: employer_dashboard.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Error: " . $sql . "<br>" . $db->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Internship</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style type="text/css">body {
    background-color: #f7f7f7;
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
}

.container {
    margin-top: 50px;
}

.sidebar {
    position: fixed;
    top: 50px; /* Adjust this to match the height of your header */
    left: 0;
    height: calc(100% - 50px); /* Ensures the sidebar height doesn’t overlap the header */
    width: 250px;
    background-color: black;
    color: white;
    padding: 10px 20px;
    overflow-y: auto;
}

.sidebar h3 {
    color: #ffc107;
    margin-bottom: 20px;
}

.sidebar .nav-link {
    color: white;
    padding: 10px 20px;
    transition: background-color 0.3s ease;
}

.sidebar .nav-link:hover {
    background-color: #555d66;
}

.main-content {
    margin-left: 250px; /* Same width as sidebar */
    padding: 20px;
    margin-top: 50px; /* Adds space so content doesn't overlap with header */
}
</style>
</head>
<body>
    <!-- Header -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Your Company Name</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="employer_dashboard.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="add_internship.php">Add New Internship</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_applications.php">View Applications</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Sidebar -->
    <div class="sidebar">
        <h3>Employer Dashboard</h3>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="employer_dashboard.php">Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="add_internship.php">Add New Internship</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="veiw_application.php">View Applications</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container">
            <h2>Add New Internship</h2>
            <form action="add_internship.php" method="post">
                <div class="form-group">
                    <label for="category">Category</label>
                    <input type="text" class="form-control" id="category" name="category" required>
                </div>
                <div class="form-group">
                    <label for="postedOn">Posted On</label>
                    <input type="date" class="form-control" id="postedOn" name="postedOn" required>
                </div>
                <div class="form-group">
                    <label for="applyBy">Apply By</label>
                    <input type="date" class="form-control" id="applyBy" name="applyBy" required>
                </div>
                <div class="form-group">
                    <label for="nameOfCompany">Name of Company</label>
                    <input type="text" class="form-control" id="nameOfCompany" name="nameOfCompany" value="<?php echo htmlspecialchars($nameOfCompany); ?>" required>
                </div>
                <div class="form-group">
                    <label for="aboutCompany">About Company</label>
                    <textarea class="form-control" id="aboutCompany" name="aboutCompany" rows="3" required><?php echo htmlspecialchars($aboutCompany); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="aboutInternship">About Internship</label>
                    <textarea class="form-control" id="aboutInternship" name="aboutInternship" rows="3" required></textarea>
                </div>
                <div class="form-group">
                    <label for="location">Location</label>
                    <input type="text" class="form-control" id="location" name="location" required>
                </div>
                <div class="form-group">
                    <label for="perks">Perks</label>
                    <textarea class="form-control" id="perks" name="perks" rows="2"></textarea>
                </div>
                <div class="form-group">
                    <label for="duration">Duration (in months)</label>
                    <input type="number" class="form-control" id="duration" name="duration" required>
                </div>
                <div class="form-group">
                    <label for="stipend">Stipend</label>
                    <input type="number" class="form-control" id="stipend" name="stipend" required>
                </div>
                <div class="form-group">
                    <label for="positions">Number of Positions</label>
                    <input type="number" class="form-control" id="positions" name="positions" required>
                </div>
                <div class="form-group">
                    <label for="whoCanApply">Who Can Apply</label>
                    <textarea class="form-control" id="whoCanApply" name="whoCanApply" rows="3"></textarea>
                </div>
               
<div class="form-group form-check">
    <input type="checkbox" class="form-check-input" id="featured" name="featured">
    <label class="form-check-label" for="featured">Featured</label>
</div>
<div class="form-group form-check">
    <input type="checkbox" class="form-check-input" id="deleted" name="deleted">
    <label class="form-check-label" for="deleted">Deleted</label>
</div>
<button type="submit" class="btn btn-primary">Add Internship</button>
<a href="employer_dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
</form>
</div>
</div>
</div>

<!-- JavaScript and Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
