<?php
session_start();
include 'config.php'; // Adjust the path as necessary

// Check if the employer is logged in
if (!isset($_SESSION['employer_id'])) {
    header("Location: login_register.php");
    exit();
}

// Check if internship ID is provided in the URL
if (!isset($_GET['id'])) {
    header("Location: employer_dashboard.php"); // Redirect if ID is missing
    exit();
}

// Get internship ID from the URL parameter
$internship_id = $_GET['id'];
$emp_id = $_SESSION['employer_id'];

// Prepare SQL statement to delete the internship
$sql = "DELETE FROM internships WHERE id = ? AND emp_id = ?";
$stmt = $db->prepare($sql);
$stmt->bind_param("ii", $internship_id, $emp_id);

// Execute the delete statement
if ($stmt->execute()) {
    $_SESSION['success_message'] = "Internship deleted successfully!";
} else {
    $_SESSION['error_message'] = "Failed to delete internship. Please try again.";
}

// Redirect to employer dashboard after deletion
header("Location: employer_dashboard.php");
exit();
?>
