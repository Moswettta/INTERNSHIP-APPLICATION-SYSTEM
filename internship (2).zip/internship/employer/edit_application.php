<?php
session_start();
include 'config.php'; // Adjust the path as necessary

// Check if the employer is logged in
if (!isset($_SESSION['employer_id'])) {
    header("Location: login_register.php");
    exit();
}

// Ensure application ID is provided via GET parameter
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: employer_dashboard.php");
    exit();
}

$application_id = $_GET['id'];
$employer_id = $_SESSION['employer_id'];

// Fetch application details
$sql = "SELECT a.*, s.fullname, s.email
        FROM applications a
        INNER JOIN student s ON a.stu_id = s.stu_id
        INNER JOIN internships i ON a.int_id = i.id
        WHERE a.id = ? AND i.emp_id = ?";
$stmt = $db->prepare($sql);

// Check if prepare() succeeded
if (!$stmt) {
    echo "Prepare failed: (" . $db->errno . ") " . $db->error;
    exit();
}

$stmt->bind_param("ii", $application_id, $employer_id);
$stmt->execute();
$result = $stmt->get_result();
$application = $result->fetch_assoc();

// If application does not exist or not owned by employer, redirect
if (!$application) {
    header("Location: employer_dashboard.php");
    exit();
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Extract submitted data
    $status = $_POST['status'];
    $feedback = $_POST['feedback'];

    // Update application details in the database
    $sql_update = "UPDATE applications SET status = ?, feedback = ? WHERE id = ?";
    $stmt_update = $db->prepare($sql_update);

    // Check if prepare() succeeded for update statement
    if (!$stmt_update) {
        echo "Prepare failed: (" . $db->errno . ") " . $db->error;
        exit();
    }

    $stmt_update->bind_param("ssi", $status, $feedback, $application_id);

    if ($stmt_update->execute()) {
        $message = "Application updated successfully";
    } else {
        $error_message = "Error updating application: " . $db->error;
    }

    // Close update statement
    $stmt_update->close();
}

// Close fetch statement and database connection
$stmt->close();
$db->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Application</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f7f7f7;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 50px;
        }
        .form-group {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Edit Application</h2>
    <?php if (isset($message)): ?>
        <div class="alert alert-success" role="alert">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>
    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo $error_message; ?>
        </div>
    <?php endif; ?>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . "?id=" . $application_id; ?>" method="post">
        <div class="form-group">
            <label for="fullname">Student Full Name</label>
            <input type="text" class="form-control" id="fullname" name="fullname" value="<?php echo htmlspecialchars($application['fullname']); ?>" readonly>
        </div>
        <div class="form-group">
            <label for="email">Student Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($application['email']); ?>" readonly>
        </div>
        <div class="form-group">
            <label for="status">Application Status</label>
            <select class="form-control" id="status" name="status" required>
                <option value="pending" <?php echo ($application['status'] == 'pending') ? 'selected' : ''; ?>>Pending</option>
                <option value="approved" <?php echo ($application['status'] == 'approved') ? 'selected' : ''; ?>>Approved</option>
                <option value="declined" <?php echo ($application['status'] == 'declined') ? 'selected' : ''; ?>>Declined</option>
            </select>
        </div>
        <div class="form-group">
            <label for="feedback">Feedback (Optional)</label>
            <textarea class="form-control" id="feedback" name="feedback" rows="3"><?php echo htmlspecialchars($application['feedback']); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Update Application</button>
        <a href="veiw_application.php" class="btn btn-secondary">Back to Applications</a>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
