<?php error_reporting(0)?>
<?php
session_start();
include 'config.php'; // Adjust the path as necessary

// Check if the employer is logged in
if (!isset($_SESSION['employer_id'])) {
    header("Location: login_register.php");
    exit();
}

// Get internship ID from URL
$internship_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($internship_id == 0) {
    echo "Invalid internship ID.";
    exit();
}

// Initialize variables
$category = $postedOn = $applyBy = $nameOfCompany = $aboutCompany = $aboutInternship = $location = $perks = $duration = $stipend = $positions = $whoCanApply = "";
$featured = $deleted = 0;
$emp_id = $_SESSION['employer_id'];

// Fetch existing internship details
$sql = "SELECT * FROM internships WHERE id = ? AND emp_id = ?";
$stmt = $db->prepare($sql);
$stmt->bind_param("ii", $internship_id, $emp_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    echo "No internship found or you do not have permission to edit this internship.";
    exit();
}
$internship = $result->fetch_assoc();

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category = $_POST['category'];
    $postedOn = $_POST['postedOn'];
    $applyBy = $_POST['applyBy'];
    $nameOfCompany = $_POST['nameOfCompany'];
    $aboutCompany = $_POST['aboutCompany'];
    $aboutInternship = $_POST['aboutInternship'];
    $location = $_POST['location'];
    $perks = $_POST['perks'];
    $duration = $_POST['duration'];
    $stipend = $_POST['stipend'];
    $positions = $_POST['positions'];
    $whoCanApply = $_POST['whoCanApply'];
    $featured = isset($_POST['featured']) ? 1 : 0;
    $deleted = isset($_POST['deleted']) ? 1 : 0;

    $sql = "UPDATE internships SET category=?, postedOn=?, applyBy=?, nameOfCompany=?, aboutCompany=?, aboutInternship=?, location=?, perks=?, duration=?, stipend=?, positions=?, whoCanApply=?, featured=?, deleted=? WHERE id=? AND emp_id=?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("sssssssssiiiiiii", $category, $postedOn, $applyBy, $nameOfCompany, $aboutCompany, $aboutInternship, $location, $perks, $duration, $stipend, $positions, $whoCanApply, $featured, $deleted, $internship_id, $emp_id);
    
    if ($stmt->execute()) {
        echo "Internship updated successfully";
        header("Location: employer_dashboard.php");
    } else {
        echo "Error: " . $sql . "<br>" . $db->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Internship</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f7f7f7;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 50px;
        }
    </style>
</head>
<?php include 'includes/header.php'; ?>
<body>
<div class="container">
    <h2>Edit Internship</h2>
    <form action="edit_internship.php?id=<?php echo $internship_id; ?>" method="post">
        <div class="form-group">
            <label for="category">Category</label>
            <input type="text" class="form-control" id="category" name="category" value="<?php echo htmlspecialchars($internship['category']); ?>" required>
        </div>
        <div class="form-group">
            <label for="postedOn">Posted On</label>
            <input type="date" class="form-control" id="postedOn" name="postedOn" value="<?php echo htmlspecialchars($internship['postedOn']); ?>" required>
        </div>
        <div class="form-group">
            <label for="applyBy">Apply By</label>
            <input type="date" class="form-control" id="applyBy" name="applyBy" value="<?php echo htmlspecialchars($internship['applyBy']); ?>" required>
        </div>
        <div class="form-group">
            <label for="nameOfCompany">Name of Company</label>
            <input type="text" class="form-control" id="nameOfCompany" name="nameOfCompany" value="<?php echo htmlspecialchars($internship['nameOfCompany']); ?>" required>
        </div>
        <div class="form-group">
            <label for="aboutCompany">About Company</label>
            <textarea class="form-control" id="aboutCompany" name="aboutCompany" rows="3" required><?php echo htmlspecialchars($internship['aboutCompany']); ?></textarea>
        </div>
        <div class="form-group">
            <label for="aboutInternship">About Internship</label>
            <textarea class="form-control" id="aboutInternship" name="aboutInternship" rows="3" required><?php echo htmlspecialchars($internship['aboutInternship']); ?></textarea>
        </div>
        <div class="form-group">
            <label for="location">Location</label>
            <input type="text" class="form-control" id="location" name="location" value="<?php echo htmlspecialchars($internship['location']); ?>" required>
        </div>
        <div class="form-group">
            <label for="perks">Perks</label>
            <textarea class="form-control" id="perks" name="perks" rows="2"><?php echo htmlspecialchars($internship['perks']); ?></textarea>
        </div>
        <div class="form-group">
            <label for="duration">Duration (in months)</label>
            <input type="number" class="form-control" id="duration" name="duration" value="<?php echo htmlspecialchars($internship['duration']); ?>" required>
        </div>
        <div class="form-group">
            <label for="stipend">Stipend</label>
            <input type="number" class="form-control" id="stipend" name="stipend" value="<?php echo htmlspecialchars($internship['stipend']); ?>" required>
        </div>
        <div class="form-group">
            <label for="positions">Number of Positions</label>
            <input type="number" class="form-control" id="positions" name="positions" value="<?php echo htmlspecialchars($internship['positions']); ?>" required>
        </div>
        <div class="form-group">
            <label for="whoCanApply">Who Can Apply</label>
            <textarea class="form-control" id="whoCanApply" name="whoCanApply" rows="3"><?php echo htmlspecialchars($internship['whoCanApply']); ?></textarea>
        </div>
        <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" id="featured" name="featured" <?php echo ($internship['featured'] ? 'checked' : ''); ?>>
            <label class="form-check-label" for="featured">Featured</label>
        </div>
        <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" id="deleted" name="deleted" <?php echo ($internship['deleted'] ? 'checked' : ''); ?>>
            <label class="form-check-label" for="deleted">Deleted</label>
        </div>
        <button type="submit" class="btn btn-primary">Update Internship</button>
        <a href="employer_dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </form>
</div>
</body>
</html>
