<?php
error_reporting(0);
?>
<?php
session_start();
include 'C:/xampp/htdocs/internship/config.php'; 
include 'includes/header.php';

if (!isset($_SESSION['email'])) {
    echo "Please log in to view this page.";
    exit();
}

// Fetch employer ID from session
$email = $_SESSION['email'];
$sqlEmp = "SELECT id FROM employer WHERE email = ?";
$stmt = $db->prepare($sqlEmp);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$employer = $result->fetch_assoc();
$emp_id = $employer['id'];

// Handle Approve/Decline Application
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['app_id'], $_POST['action'])) {
    $app_id = (int)$_POST['app_id'];
    $action = $_POST['action'] == 'approve' ? 'approved' : 'declined';
    $sqlUpdate = "UPDATE applications SET status = ? WHERE id = ?";
    $stmt = $db->prepare($sqlUpdate);
    $stmt->bind_param("si", $action, $app_id);
    $stmt->execute();
}

// Handle Delete Internship
if (isset($_GET['delete_internship'])) {
    $int_id = (int)$_GET['delete_internship'];
    $sqlDelete = "DELETE FROM internships WHERE id = ? AND emp_id = ?";
    $stmt = $db->prepare($sqlDelete);
    $stmt->bind_param("ii", $int_id, $emp_id);
    $stmt->execute();
    header("Location: employer_applications.php");
    exit();
}

// Handle Edit Internship
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_internship'])) {
    $int_id = (int)$_POST['int_id'];
    $category = $_POST['category'];
    $postedOn = $_POST['postedOn'];
    $applyBy = $_POST['applyBy'];
    $aboutCompany = $_POST['aboutCompany'];
    $aboutInternship = $_POST['aboutInternship'];
    $location = $_POST['location'];
    $perks = $_POST['perks'];
    $duration = (int)$_POST['duration'];
    $stipend = (int)$_POST['stipend'];
    $positions = (int)$_POST['positions'];
    $whoCanApply = $_POST['whoCanApply'];

    $sqlUpdate = "UPDATE internships SET 
                  category = ?, postedOn = ?, applyBy = ?, aboutCompany = ?, aboutInternship = ?, 
                  location = ?, perks = ?, duration = ?, stipend = ?, positions = ?, whoCanApply = ? 
                  WHERE id = ? AND emp_id = ?";
    $stmt = $db->prepare($sqlUpdate);
    $stmt->bind_param("sssssiiiiisii", $category, $postedOn, $applyBy, $aboutCompany, $aboutInternship, $location, $perks, $duration, $stipend, $positions, $whoCanApply, $int_id, $emp_id);
    $stmt->execute();
    header("Location: employer_applications.php");
    exit();
}

// Handle Edit Application
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_application'])) {
    $app_id = (int)$_POST['app_id'];
    $status = $_POST['status'];
    
    $sqlUpdate = "UPDATE applications SET status = ? WHERE id = ?";
    $stmt = $db->prepare($sqlUpdate);
    $stmt->bind_param("si", $status, $app_id);
    $stmt->execute();
    header("Location: employer_applications.php");
    exit();
}

// Fetch internships posted by the employer
$sqlInternships = "SELECT * FROM internships WHERE emp_id = ?";
$stmt = $db->prepare($sqlInternships);
$stmt->bind_param("i", $emp_id);
$stmt->execute();
$internships = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Add your meta tags, title, and CSS links here -->
</head>
<body>
<div class="container-fluid">
    <h2 class="text-center">Your Internship Positions and Applicants</h2>
    <?php while ($internship = $internships->fetch_assoc()): ?>
        <div class="card my-4">
            <div class="card-header">
                <h4><?= htmlspecialchars($internship['category']); ?> Internship at <?= htmlspecialchars($internship['nameOfCompany']); ?></h4>
                <div class="float-right">
                    <a href="employer_applications.php?edit_internship=<?= $internship['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="employer_applications.php?delete_internship=<?= $internship['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this internship?');">Delete</a>
                </div>
            </div>
            <div class="card-body">
                <?php
                $int_id = $internship['id'];
                $sqlApplications = "
                    SELECT applications.id AS app_id, student.fullname, student.email, student.phone, applications.applied, applications.status, internships.category
                    FROM applications
                    JOIN student ON applications.stu_id = student.id
                    JOIN internships ON applications.int_id = internships.id
                    WHERE applications.int_id = ?";
                $stmt = $db->prepare($sqlApplications);
                $stmt->bind_param("i", $int_id);
                $stmt->execute();
                $applications = $stmt->get_result();
                ?>

                <?php if ($applications->num_rows > 0): ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Internship Position</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($applicant = $applications->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($applicant['fullname']); ?></td>
                                    <td><?= htmlspecialchars($applicant['email']); ?></td>
                                    <td><?= htmlspecialchars($applicant['phone']); ?></td>
                                    <td><?= htmlspecialchars($applicant['category']); ?></td>
                                    <td><?= htmlspecialchars($applicant['status']); ?></td>
                                    <td>
                                        <?php if ($applicant['status'] == 'pending'): ?>
                                            <form action="employer_applications.php" method="POST" style="display:inline;">
                                                <input type="hidden" name="app_id" value="<?= $applicant['app_id']; ?>">
                                                <button type="submit" name="action" value="approve" class="btn btn-success btn-sm">Approve</button>
                                            </form>
                                            <form action="employer_applications.php" method="POST" style="display:inline;">
                                                <input type="hidden" name="app_id" value="<?= $applicant['app_id']; ?>">
                                                <button type="submit" name="action" value="decline" class="btn btn-danger btn-sm">Decline</button>
                                            </form>
                                            <a href="employer_applications.php?edit_application=<?= $applicant['app_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                        <?php else: ?>
                                            <?= htmlspecialchars(ucfirst($applicant['status'])); ?>
                                            <a href="employer_applications.php?edit_application=<?= $applicant['app_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No applications yet.</p>
                <?php endif; ?>
            </div>
        </div>
    <?php endwhile; ?>
</div>

<?php if (isset($_GET['edit_internship'])): ?>
    <?php
    $edit_int_id = (int)$_GET['edit_internship'];
    $sqlEdit = "SELECT * FROM internships WHERE id = ? AND emp_id = ?";
    $stmt = $db->prepare($sqlEdit);
    $stmt->bind_param("ii", $edit_int_id, $emp_id);
    $stmt->execute();
    $editInternship = $stmt->get_result()->fetch_assoc();
    ?>
    <div class="container">
        <h2 class="text-center">Edit Internship</h2>
        <form action="employer_applications.php" method="POST">
            <input type="hidden" name="edit_internship" value="1">
            <input type="hidden" name="int_id" value="<?= $editInternship['id']; ?>">
            <div class="form-group">
                <label for="category">Category</label>
                <input type="text" class="form-control" name="category" value="<?= htmlspecialchars($editInternship['category']); ?>">
            </div>
            <div class="form-group">
                <label for="postedOn">Posted On</label>
                <input type="text" class="form-control" name="postedOn" value="<?= htmlspecialchars($editInternship['postedOn']); ?>">
            </div>
            <div class="form-group">
                <label for="applyBy">Apply By</label>
                <input type="text" class="form-control" name="applyBy" value="<?= htmlspecialchars($editInternship['applyBy']); ?>">
            </div>
            <div class="form-group">
                <label for="aboutCompany">About Company</label>
                <textarea class="form-control" name="aboutCompany"><?= htmlspecialchars($editInternship['aboutCompany']); ?></textarea>
            </div>
            <div class="form-group">
                <label for="aboutInternship">About Internship</label>
                <textarea class="form-control" name="aboutInternship"><?= htmlspecialchars($editInternship['aboutInternship']); ?></textarea>
            </div>
            <div class="form-group">
                <label for="location">Location</label>
                <input type="text" class="form-control" name="location" value="<?= htmlspecialchars($editInternship['location']); ?>">
            </div>
            <div class="form-group">
                <label for="perks">Perks</label>
                <input type="text" class="form-control" name="perks" value="<?= htmlspecialchars($editInternship['perks']); ?>">
            </div>
            <div class="form-group">
                <label for="duration">Duration (months)</label>
                <input type="number" class="form-control" name="duration" value="<?= (int)$editInternship['duration']; ?>">
            </div>
            <div class="form-group">
                <label for="stipend">Stipend (₹)</label>
                <input type="number" class="form-control" name="stipend" value="<?= (int)$editInternship['stipend']; ?>">
            </div>
            <div class="form-group">
                <label for="positions">Available Positions</label>
                <input type="number" class="form-control" name="positions" value="<?= (int)$editInternship['positions']; ?>">
            </div>
            <div class="form-group">
                <label for="whoCanApply">Who Can Apply</label>
                <textarea class="form-control" name="whoCanApply"><?= htmlspecialchars($editInternship['whoCanApply']); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update Internship</button>
        </form>
    </div>
<?php endif; ?>

<?php if (isset($_GET['edit_application'])): ?>
    <?php
    $edit_app_id = (int)$_GET['edit_application'];
    $sqlEditApp = "SELECT * FROM applications WHERE id = ?";
    $stmt = $db->prepare($sqlEditApp);
    $stmt->bind_param("i", $edit_app_id);
    $stmt->execute();
    $editApplication = $stmt->get_result()->fetch_assoc();
    ?>
    <div class="container">
        <h2 class="text-center">Edit Application</h2>
        <form action="employer_applications.php" method="POST">
            <input type="hidden" name="edit_application" value="1">
            <input type="hidden" name="app_id" value="<?= $editApplication['id']; ?>">
            <div class="form-group">
                <label for="status">Status</label>
                <select class="form-control" name="status">
                    <option value="pending" <?= $editApplication['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="approved" <?= $editApplication['status'] == 'approved' ? 'selected' : ''; ?>>Approved</option>
                    <option value="declined" <?= $editApplication['status'] == 'declined' ? 'selected' : ''; ?>>Declined</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Update Application</button>
        </form>
    </div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
</body>
</html>