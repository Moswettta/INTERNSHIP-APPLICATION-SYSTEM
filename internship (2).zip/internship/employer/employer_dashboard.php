<?php error_reporting(0)?>
<?php
session_start();
include 'config.php'; // Adjust the path as necessary

// Check if the employer is logged in
if (!isset($_SESSION['employer_id'])) {
    header("Location: login_register.php");
    exit();
}

// Fetch the logged-in employer's details
$employer_id = $_SESSION['employer_id'];
$employer_name = $_SESSION['employer_name'];

// Fetch internships posted by the logged-in employer along with the number of applications
$sql = "SELECT i.*, 
               (SELECT COUNT(*) FROM applications a WHERE a.int_id = i.id) as num_applications 
        FROM internships i 
        WHERE i.emp_id = ?";
$stmt = $db->prepare($sql);
$stmt->bind_param("i", $employer_id);
$stmt->execute();
$result = $stmt->get_result();
$internships = $result->fetch_all(MYSQLI_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employer Dashboard</title>
    <style>
        body {
            background-color: #f7f7f7;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container-fluid {
            padding-left: 0;
            display: flex;
            flex-direction: row;
            height: 100vh;
        }
        .sidebar {
            background-color: #343a40;
            color: white;
            width: 20%;
            padding: 20px;
        }
        .sidebar h3 {
            color: #ffc107;
            margin-bottom: 20px;
        }
        .sidebar .nav-link {
            color: white;
            padding: 10px 20px;
            display: block;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }
        .sidebar .nav-link:hover {
            background-color: #555d66;
        }
        .main-content {
            width: 80%;
            padding: 20px;
        }
        .main-content .btn-primary {
            background-color: #007bff;
            border: none;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            display: inline-block;
            margin-bottom: 20px;
        }
        .main-content .btn-primary:hover {
            background-color: #0069d9;
        }
        .card {
            background-color: white;
            border: 1px solid #ced4da;
            border-radius: 5px;
            margin-bottom: 20px;
            padding: 20px;
        }
        .card-title {
            font-size: 1.25rem;
            margin-bottom: 10px;
        }
        .card-text {
            color: #6c757d;
        }
        .btn-warning, .btn-danger {
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            display: inline-block;
            margin-right: 10px;
        }
        .btn-warning {
            background-color: #ffc107;
        }
        .btn-warning:hover {
            background-color: #e0a800;
        }
        .btn-danger {
            background-color: #dc3545;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
<?php include 'includes/header.php'; ?>
<div class="container-fluid">
    <div class="sidebar">
        <h3>Employer Dashboard</h3>
        <a class="nav-link" href="employer_dashboard.php">Dashboard</a>
        <a class="nav-link" href="add_internship.php">Add New Internship</a>
        <a class="nav-link" href="veiw_application.php">View Applications</a>
        <a class="nav-link" href="logout.php">Logout</a>
    </div>
    <div class="main-content">
        <a href="add_internship.php" class="btn-primary">Add New Internship</a>
        <!-- Display internships posted by the logged-in employer -->
        <?php foreach ($internships as $internship): ?>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($internship['nameOfCompany']); ?></h5>
                    <p class="card-text"><strong>Category:</strong> <?php echo htmlspecialchars($internship['category']); ?></p>
                    <p class="card-text"><strong>Location:</strong> <?php echo htmlspecialchars($internship['location']); ?></p>
                    <p class="card-text"><strong>Duration:</strong> <?php echo htmlspecialchars($internship['duration']); ?> months</p>
                    <p class="card-text"><strong>Stipend:</strong> <?php echo htmlspecialchars($internship['stipend']); ?></p>
                    <p class="card-text"><strong>Applications:</strong> <?php echo $internship['num_applications']; ?></p>
                    <a href="edit_internship.php?id=<?php echo $internship['id']; ?>" class="btn-warning">Edit</a>
                    <a href="delete_internship.php?id=<?php echo $internship['id']; ?>" class="btn-danger">Delete</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
</body>
</html>
