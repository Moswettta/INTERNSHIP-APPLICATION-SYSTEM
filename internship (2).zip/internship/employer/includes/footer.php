
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Management System</p>
    </footer>