<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employer Dashboard</title>
    <style>
        body {
            background-color: #f7f7f7;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: black;
            color: #fff;
            padding: 10px 0;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h2 {
            margin: 0;
            padding-left: 20px;
        }

        .header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
        }

        .profile-btn,
        .logout-btn {
            color: #fff;
            text-decoration: none;
            padding: 8px 12px;
            margin-left: 10px;
            border-radius: 4px;
            transition: background-color 0.3s ease;
            border: 1px solid #fff;
        }

        .profile-btn:hover,
        .logout-btn:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }

        .welcome-message {
            margin-right: auto;
            padding-left: 20px;
        }
    </style>
</head>

<body>
    <div class="header">
        <div class="container">
            <h2>Employer Dashboard</h2>
            <span class="welcome-message">Welcome, <?php echo htmlspecialchars($_SESSION['employer_name']); ?></span>
            <a href="profile.php" class="profile-btn">Profile</a>
            <a href="employer_dashboard.php" class="profile-btn">HOME</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </div>
</body>

</html>
