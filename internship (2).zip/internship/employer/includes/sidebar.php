<?php
session_start();
?>

<?php 
if(!isset($_SESSION['email'])){
    echo "<script>window.open('login.php','_self')</script>";
}else{
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employer Applications</title>
       <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: Arial, sans-serif;
        }
        .container {
            display: flex;
        }
        .sidebar {
            width: 250px;
            background: #343a40;
            color: #fff;
            padding: 15px;
            margin-right: auto; /* Push sidebar to the far left */
        }
        .sidebar h2 {
            margin-bottom: 20px;
        }
        .sidebar a {
            color: #fff;
            text-decoration: none;
            display: block;
            padding: 10px 0;
            transition: background 0.3s ease;
        }
        .sidebar a:hover {
            background: #495057;
        }
        .main-content {
            flex: 1;
            padding: 20px;
        }
        .card {
            margin-bottom: 20px;
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 20px;
        }
        .card-title {
            margin-bottom: 10px;
            font-size: 20px;
        }
        .card-text {
            font-size: 24px;
            color: #007bff;
            font-weight: bold;
        }
    </style>
</head>
<body>
<div class="flex-container">
    <div class="flex-content">
        <div class="sidebar">
     <div class="container">
    <div class="sidebar">
        <h2>Navigation</h2>
        <a href="#">Dashboard</a>
        <a href="employer_applications.php">All Applications</a>
        <a href="employer_applications.php">ALL Internships</a>
        <a href="internship.php">ADD Internship</a>
        <a href="myaccount.php">Settings</a>
        <a href="login.php">Logout</a>
    </div>
    <div class="main-content">
        <div class="container">
            <h2 class="text-center">Dashboard</h2>
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Number of Advertised Internships</h5>
                            <p class="card-text"><?php echo $internshipCount['num_internships']; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Number of Students Who Applied</h5>
                            <p class="card-text"><?php echo $studentCount['num_students']; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include 'includes/footer.php'; ?>
</div>
</body>
</html>

<?php } ?>
