<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// Database connection settings
$db_host = 'localhost';
$db_user = 'root';
$db_password = '';
$db_name = 'internship';

// Create connection
$db = new mysqli($db_host, $db_user, $db_password, $db_name);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

if (!isset($_SESSION['email'])) {
    echo "<script>window.open('login.php','_self')</script>";
    exit();
}

include 'C:/xampp/htdocs/internship/config.php';
include('includes/header.php');

// Fetch employer ID from session
$email = $_SESSION['email'];
$sqlEmp = "SELECT id FROM employer WHERE email = ?";
$stmt = $db->prepare($sqlEmp);
if ($stmt === false) {
    die("Error preparing statement for employer ID: " . $db->error);
}
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
if ($result === false) {
    die("Error executing statement for employer ID: " . $stmt->error);
}
$employer = $result->fetch_assoc();
if (!$employer) {
    die("No employer found with email: " . $email);
}
$emp_id = $employer['id'];

// Count advertised internships
$sqlInternshipCount = "SELECT COUNT(*) AS num_internships FROM internships WHERE emp_id = ?";
$stmt = $db->prepare($sqlInternshipCount);
if ($stmt === false) {
    die("Error preparing statement for internship count: " . $db->error);
}
$stmt->bind_param("i", $emp_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result === false) {
    die("Error executing statement for internship count: " . $stmt->error);
}
$internshipCount = $result->fetch_assoc();

// Count students who applied
$sqlStudentCount = "SELECT COUNT(DISTINCT stu_id) AS num_students FROM applications WHERE int_id IN (SELECT id FROM internships WHERE emp_id = ?)";
$stmt = $db->prepare($sqlStudentCount);
if ($stmt === false) {
    die("Error preparing statement for student count: " . $db->error);
}
$stmt->bind_param("i", $emp_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result === false) {
    die("Error executing statement for student count: " . $stmt->error);
}
$studentCount = $result->fetch_assoc();

// Fetch internships advertised by the employer
$sqlInternships = "SELECT * FROM internships WHERE emp_id = ?";
$stmt = $db->prepare($sqlInternships);
if ($stmt === false) {
    die("Error preparing statement for internships: " . $db->error);
}
$stmt->bind_param("i", $emp_id);
$stmt->execute();
$internshipsResult = $stmt->get_result();
if ($internshipsResult === false) {
    die("Error executing statement for internships: " . $stmt->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employer Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: Arial, sans-serif;
        }
        .sidebar {
            width: 250px;
            background: #343a40;
            color: #fff;
            padding: 15px;
            height: 100%;
            position: fixed;
        }
        .sidebar h2 {
            margin-bottom: 20px;
        }
        .sidebar a {
            color: #fff;
            text-decoration: none;
            display: block;
            padding: 10px 0;
            transition: background 0.3s ease;
        }
        .sidebar a:hover {
            background: #495057;
        }
        .main-content {
            margin-left: 250px; /* Same width as the sidebar */
            padding: 20px;
        }
        .card {
            margin-bottom: 20px;
        }
        .card-title {
            margin-bottom: 10px;
            font-size: 20px;
        }
        .card-text {
            font-size: 24px;
            color: #007bff;
            font-weight: bold;
        }
        .internships {
            margin-top: 20px;
        }
        .internship-card {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="sidebar">
            <h2>Navigation</h2>
            <a href="#">Dashboard</a>
            <a href="employer_applications.php">All Applications</a>
            <a href="employer_applications.php">All Internships</a>
            <a href="internship.php">Add Internship</a>
            <a href="myaccount.php">Settings</a>
            <a href="login.php">Logout</a>
        </div>
        <div class="main-content col">
            <h2 class="text-center">Dashboard</h2>
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Number of Advertised Internships</h5>
                            <p class="card-text"><?php echo $internshipCount['num_internships']; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Number of Students Who Applied</h5>
                            <p class="card-text"><?php echo $studentCount['num_students']; ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="internships">
                <h3>Internships Advertised by You</h3>
                <div class="row">
                    <?php while ($internship = $internshipsResult->fetch_assoc()): ?>
                        <div class="col-md-4">
                            <div class="card internship-card">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo htmlspecialchars($internship['category']); ?></h5>
                                    <p class="card-text"><strong>Posted On:</strong> <?php echo htmlspecialchars($internship['postedOn']); ?></p>
                                    <p class="card-text"><strong>Apply By:</strong> <?php echo htmlspecialchars($internship['applyBy']); ?></p>
                                    <p class="card-text"><strong>Location:</strong> <?php echo htmlspecialchars($internship['location']); ?></p>
                                    <p class="card-text"><strong>Duration:</strong> <?php echo htmlspecialchars($internship['duration']); ?> months</p>
                                    <p class="card-text"><strong>Stipend:</strong> $<?php echo htmlspecialchars($internship['stipend']); ?></p>
                                    <a href="internship_detail.php?id=<?php echo $internship['id']; ?>" class="btn btn-primary">View Details</a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
<!-- Bootstrap JS, Popper.js, and jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
