<?php
session_start();
include 'config.php'; // Adjust the path as necessary

// Function to sanitize input data
function sanitizeInput($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Handle Registration
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    $nameOfCompany = sanitizeInput($_POST['nameOfCompany']);
    $aboutCompany = sanitizeInput($_POST['aboutCompany']);
    $email = sanitizeInput($_POST['email']);
    $password = password_hash(sanitizeInput($_POST['password']), PASSWORD_BCRYPT);
    $address1 = sanitizeInput($_POST['address1']);
    $address2 = sanitizeInput($_POST['address2']);
    $city = sanitizeInput($_POST['city']);
    $state = sanitizeInput($_POST['state']);
    $zipcode = (int)sanitizeInput($_POST['zipcode']);
    $phone = sanitizeInput($_POST['phone']);
    $country = sanitizeInput($_POST['country']);
    $ip = $_SERVER['REMOTE_ADDR'];

    // Check if the email already exists
    $sql = "SELECT * FROM employer WHERE email = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        echo "Email already exists. Please choose another one.";
    } else {
        // Insert the new employer into the database
        $sql = "INSERT INTO employer (nameOfCompany, aboutCompany, email, password, address1, address2, city, state, zipcode, phone, country, ip) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $db->prepare($sql);
        $stmt->bind_param("ssssssssisss", $nameOfCompany, $aboutCompany, $email, $password, $address1, $address2, $city, $state, $zipcode, $phone, $country, $ip);
        if ($stmt->execute()) {
            echo "Registration successful. Please log in.";
        } else {
            echo "Error: " . $stmt->error;
        }
    }
}

// Handle Login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $email = sanitizeInput($_POST['email']);
    $password = sanitizeInput($_POST['password']);

    // Check the credentials
    $sql = "SELECT * FROM employer WHERE email = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $employer = $result->fetch_assoc();
        if (password_verify($password, $employer['password'])) {
            $_SESSION['employer_id'] = $employer['id'];
            $_SESSION['employer_name'] = $employer['nameOfCompany'];
            header("Location: employer_dashboard.php"); // Redirect to employer dashboard
            exit();
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "No user found with this email.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employer Login & Registration</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f4f4f9;
            font-family: 'Arial', sans-serif;
        }
        .header {
            background-color: #333;
            color: white;
            padding: 15px 0;
            text-align: center;
            position: relative;
        }
        .header .home-btn {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 18px;
            color: white;
            text-decoration: none;
        }
        .container {
            margin-top: 50px;
        }
        .form-container {
            background-color: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .form-container h3 {
            margin-bottom: 30px;
            color: #333;
            text-align: center;
        }
        .form-group label {
            color: #555;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #004085;
        }
        .toggle-link {
            text-align: center;
            margin-top: 20px;
        }
        .toggle-link a {
            color: #007bff;
            text-decoration: none;
        }
        .toggle-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="header">
        <a href="/internship/index.php" class="home-btn">Home</a>
        <h2>Login / Register</h2>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <!-- Login Form -->
                <div class="form-container" id="login-form">
                    <h3>Login</h3>
                    <form action="login_register.php" method="POST">
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password:</label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block" name="login">Login</button>
                    </form>
                    <div class="toggle-link">
                        <p>Don't have an account? <a href="javascript:void(0);" onclick="toggleForms()">Register Here</a></p>
                    </div>
                </div>

                <!-- Registration Form -->
                <div class="form-container" id="register-form" style="display: none;">
                    <h3>Register</h3>
                    <form action="login_register.php" method="POST">
                        <div class="form-group">
                            <label for="nameOfCompany">Name of Company:</label>
                            <input type="text" class="form-control" name="nameOfCompany" required>
                        </div>
                        <div class="form-group">
                            <label for="aboutCompany">About Company:</label>
                            <textarea class="form-control" name="aboutCompany" required></textarea>
                        </div>
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password:</label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
                        <div class="form-group">
                            <label for="address1">Address 1:</label>
                            <input type="text" class="form-control" name="address1" required>
                        </div>
                        <div class="form-group">
                            <label for="address2">Address 2:</label>
                            <input type="text" class="form-control" name="address2">
                        </div>
                        <div class="form-group">
                            <label for="city">City:</label>
                            <input type="text" class="form-control" name="city" required>
                        </div>
                        <div class="form-group">
                            <label for="state">State:</label>
                            <input type="text" class="form-control" name="state">
                        </div>
                        <div class="form-group">
                            <label for="zipcode">Zipcode:</label>
                            <input type="number" class="form-control" name="zipcode" required>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone:</label>
                            <input type="text" class="form-control" name="phone" required>
                        </div>
                        <div class="form-group">
                            <label for="country">Country:</label>
                            <input type="text" class="form-control" name="country" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block" name="register">Register</button>
                    </form>
                    <div class="toggle-link">
                        <p>Already have an account? <a href="javascript:void(0);" onclick="toggleForms()">Login Here</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function toggleForms() {
            var loginForm = document.getElementById('login-form');
            var registerForm = document.getElementById('register-form');
            if (loginForm.style.display === "none") {
                loginForm.style.display = "block";
                registerForm.style.display = "none";
            } else {
                loginForm.style.display = "none";
                registerForm.style.display = "block";
            }
        }
    </script>
</body>
</html>
