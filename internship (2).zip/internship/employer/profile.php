<?php error_reporting(0);?>
<?php
session_start();
include 'includes/header.php';

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "internship"; // Adjust database name as needed

// Create connection
$db = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Check if the employer is logged in
if (!isset($_SESSION['employer_id'])) {
    header("Location: login_register.php");
    exit();
}

// Fetch the logged-in employer's details
$employer_id = $_SESSION['employer_id'];
$sql = "SELECT * FROM employer WHERE id = ?";
$stmt = $db->prepare($sql);

if (!$stmt) {
    // Handle error if prepare fails
    die("Prepare failed: (" . $db->errno . ") " . $db->error);
}

$stmt->bind_param("i", $employer_id);
$stmt->execute();

$result = $stmt->get_result();
if (!$result) {
    // Handle error if get_result fails
    die("Get result failed: (" . $stmt->errno . ") " . $stmt->error);
}

$employer = $result->fetch_assoc();

// Handle form submission for editing profile
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming form fields are 'nameOfCompany', 'aboutCompany', 'email', etc.
    $nameOfCompany = $_POST['nameOfCompany'];
    $aboutCompany = $_POST['aboutCompany'];
    $email = $_POST['email'];
    // Add more fields as needed

    // Update the employer's profile in the database
    $update_sql = "UPDATE employer SET nameOfCompany = ?, aboutCompany = ?, email = ? WHERE id = ?";
    $update_stmt = $db->prepare($update_sql);

    if (!$update_stmt) {
        // Handle error if prepare fails
        die("Prepare failed: (" . $db->errno . ") " . $db->error);
    }

    $update_stmt->bind_param("sssi", $nameOfCompany, $aboutCompany, $email, $employer_id);
    if ($update_stmt->execute()) {
        // Update successful, redirect to index.php with success message
        $_SESSION['success_message'] = "Profile updated successfully!";
        header("Location: employer_dashboard.php");
        exit();
    } else {
        // Update failed, handle errors
        $error_message = "Failed to update profile. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employer Profile</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f7f7f7;
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 600px;
            margin-top: 50px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .btn-primary {
            margin-top: 10px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2 class="mt-4 mb-4">Employer Profile</h2>
    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo $error_message; ?>
        </div>
    <?php endif; ?>
    <form action="profile.php" method="POST">
        <div class="form-group">
            <label for="nameOfCompany">Company Name</label>
            <input type="text" class="form-control" id="nameOfCompany" name="nameOfCompany" value="<?php echo htmlspecialchars($employer['nameOfCompany']); ?>" required>
        </div>
        <div class="form-group">
            <label for="aboutCompany">About Company</label>
            <textarea class="form-control" id="aboutCompany" name="aboutCompany" rows="3" required><?php echo htmlspecialchars($employer['aboutCompany']); ?></textarea>
        </div>
        <div class="form-group">
            <label for="email">Contact Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($employer['email']); ?>" required>
        </div>
        <!-- Add more fields as needed -->

        <button type="submit" class="btn btn-primary">Update Profile</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
