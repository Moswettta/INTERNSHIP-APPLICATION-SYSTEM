<?php
session_start();
include 'config.php'; // Adjust the path as necessary

// Check if the employer is logged in
if (!isset($_SESSION['employer_id'])) {
    header("Location: login_register.php");
    exit();
}

// Function to fetch internships posted by the logged-in employer
function fetchInternships($db, $employer_id) {
    $sql = "SELECT * FROM internships WHERE emp_id = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("i", $employer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to fetch applications for a specific internship
function fetchApplications($db, $internship_id) {
    $sql = "SELECT a.*, s.fullname, s.email
            FROM applications a
            INNER JOIN student s ON a.stu_id = s.stu_id
            WHERE a.int_id = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("i", $internship_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Handle action to accept or reject application
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action']) && isset($_POST['app_id'])) {
        $action = $_POST['action'];
        $app_id = $_POST['app_id'];

        // Update application status based on action
        $sql = "UPDATE applications SET status = ? WHERE id = ?";
        $stmt = $db->prepare($sql);
        $stmt->bind_param("si", $action, $app_id);
        $stmt->execute();
    }
}

// Fetch the logged-in employer's details
$employer_id = $_SESSION['employer_id'];
$employer_name = $_SESSION['employer_name'];

// Fetch internships posted by the logged-in employer
$internships = fetchInternships($db, $employer_id);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Applications</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            height: 100vh;
            flex-direction: column;
        }
        header {
    background-color: black;
    color: white;
    padding: 3px 10px; /* Further reduced padding */
    text-align: center;
    font-size: 16px; /* Smaller font size for reduced height */
    line-height: 1.1; /* Adjust line height for compactness */
}

        .container {
            display: flex;
            flex: 1;
        }
        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: #fff;
            padding: 15px;
            position: sticky;
            top: 0;
            height: 100vh;
        }
        .sidebar h3 {
            text-align: center;
            margin-bottom: 20px;
        }
        .sidebar .nav {
            list-style-type: none;
            padding: 0;
        }
        .sidebar .nav-item {
            margin-bottom: 10px;
        }
        .sidebar .nav-link {
            color: #ecf0f1;
            text-decoration: none;
            font-size: 16px;
        }
        .sidebar .nav-link:hover {
            color: #1abc9c;
        }
        .content {
            flex-grow: 1;
            padding: 20px;
            overflow-y: auto;
        }
        .card {
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .card-body {
            font-size: 16px;
        }
        .btn {
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            border: none;
            margin: 0 5px;
        }
        .btn-success {
            background-color: #27ae60;
            color: white;
        }
        .btn-danger {
            background-color: #e74c3c;
            color: white;
        }
        .btn-primary {
            background-color: #3498db;
            color: white;
        }
        .badge {
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 14px;
        }
        .badge-success {
            background-color: #2ecc71;
            color: white;
        }
        .badge-danger {
            background-color: #e74c3c;
            color: white;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <h2>Welcome, <?php echo htmlspecialchars($employer_name); ?></h2>
    </header>

    <!-- Page Content -->
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <h3>Employer Dashboard</h3>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="employer_dashboard.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="add_internship.php">Add New Internship</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_application.php">View Applications</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>

        <!-- Main Content Area -->
        <div class="content">
            <h3>View Applications</h3>
            <?php if (count($internships) > 0): ?>
                <?php foreach ($internships as $internship): ?>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($internship['nameOfCompany']); ?></h5>
                            <p class="card-text"><strong>Category:</strong> <?php echo htmlspecialchars($internship['category']); ?></p>
                            <p class="card-text"><strong>Location:</strong> <?php echo htmlspecialchars($internship['location']); ?></p>
                            <p class="card-text"><strong>Duration:</strong> <?php echo htmlspecialchars($internship['duration']); ?> months</p>
                            <p class="card-text"><strong>Stipend:</strong> <?php echo htmlspecialchars($internship['stipend']); ?></p>
                            <h5>Applications:</h5>
                            <?php
                            $applications = fetchApplications($db, $internship['id']);
                            if (count($applications) > 0): ?>
                                <ul class="list-group">
                                    <?php foreach ($applications as $application): ?>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <?php echo htmlspecialchars($application['fullname']); ?> - <?php echo htmlspecialchars($application['email']); ?>
                                            <div>
                                                <?php if ($application['status'] == 'pending'): ?>
                                                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="d-inline">
                                                        <input type="hidden" name="action" value="approved">
                                                        <input type="hidden" name="app_id" value="<?php echo $application['id']; ?>">
                                                        <button type="submit" class="btn btn-success">Accept</button>
                                                    </form>
                                                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="d-inline">
                                                        <input type="hidden" name="action" value="declined">
                                                        <input type="hidden" name="app_id" value="<?php echo $application['id']; ?>">
                                                        <button type="submit" class="btn btn-danger">Reject</button>
                                                    </form>
                                                    <!-- Debugging output for Edit link -->
                                                    <a href="edit_application.php?id=<?php echo $application['id']; ?>" class="btn btn-primary ml-2">Edit</a>
                                                <?php else: ?>
                                                    <span class="badge badge-<?php echo $application['status'] == 'approved' ? 'success' : 'danger'; ?>"><?php echo ucfirst($application['status']); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <p>No applications yet.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>You have not posted any internships yet.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
