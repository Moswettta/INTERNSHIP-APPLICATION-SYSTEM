<?php
session_start();
include 'config.php'; // Adjust the path as necessary

// Check if the employer is logged in
if (!isset($_SESSION['employer_id'])) {
    header("Location: login_register.php");
    exit();
}

// Function to fetch internships posted by the logged-in employer
function fetchInternships($db, $employer_id) {
    $sql = "SELECT * FROM internships WHERE emp_id = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("i", $employer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to fetch applications for a specific internship
function fetchApplications($db, $internship_id) {
    $sql = "SELECT a.*, s.fullname, s.email
            FROM applications a
            INNER JOIN student s ON a.stu_id = s.stu_id
            WHERE a.int_id = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("i", $internship_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Handle action to accept or reject application
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action']) && isset($_POST['app_id'])) {
        $action = $_POST['action'];
        $app_id = $_POST['app_id'];

        // Update application status based on action
        $sql = "UPDATE applications SET status = ? WHERE id = ?";
        $stmt = $db->prepare($sql);
        $stmt->bind_param("si", $action, $app_id);
        $stmt->execute();
    }
}

// Fetch the logged-in employer's details
$employer_id = $_SESSION['employer_id'];
$employer_name = $_SESSION['employer_name'];

// Fetch internships posted by the logged-in employer
$internships = fetchInternships($db, $employer_id);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Applications</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f7f7f7;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 50px;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
            text-align: center;
            margin-bottom: 30px;
        }
        .logout-btn {
            margin-left: auto;
        }
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            width: 250px;
            padding-top: 60px; /* Adjust based on header height */
            background-color: #333;
            color: #fff;
        }
        .sidebar a {
            padding: 10px;
            display: block;
            color: #fff;
            text-decoration: none;
        }
        .sidebar a:hover {
            background-color: #555;
        }
        .content {
            margin-left: 270px; /* Adjust based on sidebar width */
            padding: 20px;
        }
        .card {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            Employer Dashboard
        </div>
        <a href="employer_dashboard.php">Dashboard</a>
        <a href="add_internship.php">Add Internship</a>
        <a href="view_applications.php">View Applications</a>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>

    <!-- Page Content -->
    <div class="content">
        <div class="header">
            <h2>Welcome, <?php echo htmlspecialchars($employer_name); ?></h2>
        </div>

        <div class="container">
            <h3>View Applications</h3>
            <?php if (count($internships) > 0): ?>
                <?php foreach ($internships as $internship): ?>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($internship['nameOfCompany']); ?></h5>
                            <p class="card-text"><strong>Category:</strong> <?php echo htmlspecialchars($internship['category']); ?></p>
                            <p class="card-text"><strong>Location:</strong> <?php echo htmlspecialchars($internship['location']); ?></p>
                            <p class="card-text"><strong>Duration:</strong> <?php echo htmlspecialchars($internship['duration']); ?> months</p>
                            <p class="card-text"><strong>Stipend:</strong> <?php echo htmlspecialchars($internship['stipend']); ?></p>
                            <h5>Applications:</h5>
                            <?php
                            $applications = fetchApplications($db, $internship['id']);
                            if (count($applications) > 0): ?>
                                <ul class="list-group">
                                    <?php foreach ($applications as $application): ?>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <?php echo htmlspecialchars($application['fullname']); ?> - <?php echo htmlspecialchars($application['email']); ?>
                                            <div>
                                                <?php if ($application['status'] == 'pending'): ?>
                                                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="d-inline">
                                                        <input type="hidden" name="action" value="approved">
                                                        <input type="hidden" name="app_id" value="<?php echo $application['id']; ?>">
                                                        <button type="submit" class="btn btn-success">Accept</button>
                                                    </form>
                                                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="d-inline">
                                                        <input type="hidden" name="action" value="declined">
                                                        <input type="hidden" name="app_id" value="<?php echo $application['id']; ?>">
                                                        <button type="submit" class="btn btn-danger">Reject</button>
                                                    </form>
                                                    <a href="edit_application.php?id=<?php echo $application['id']; ?>" class="btn btn-primary ml-2">Edit</a>
                                                <?php else: ?>
                                                    <span class="badge badge-<?php echo $application['status'] == 'approved' ? 'success' : 'danger'; ?>"><?php echo ucfirst($application['status']); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <p>No applications yet.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>You have not posted any internships yet.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- JavaScript and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
