<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "internship";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch company information
function fetchCompanyInfo($conn, $emp_id) {
    $sql = "SELECT nameOfCompany, aboutCompany FROM employer WHERE id = $emp_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return false;
    }
}

// Fetch company information for the logged-in employer (assuming emp_id is 3)
$emp_id = 3; // Replace with actual logged-in employer ID retrieval logic if applicable
$companyInfo = fetchCompanyInfo($conn, $emp_id);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Internship Listings</title>
    <!-- Bootstrap CSS -->
    
    <style>
        /* Custom CSS */
        body {
            background-color: yellow; /* Set the background color to yellow */
        }

        .container-fluid {
            padding: 20px;
        }

        .internship-card {
            position: relative;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 20px;
            background-color: #fff; /* White background for the card */
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            transition: transform 0.3s ease-in-out;
        }

        .internship-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.2);
        }

        .card-body {
            padding: 20px;
        }

        .card-title {
            font-size: 1.25rem;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .card-subtitle {
            font-size: 1rem;
            color: #666;
            margin-bottom: 10px;
        }

        .card-text {
            font-size: 0.9rem;
            margin-bottom: 8px;
        }

        .btn-apply {
            
            color: #fff;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .btn-apply:hover {
        
            color: #fff;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container-fluid">
        <h2 class="text-center mb-4">Internship Listings</h2>

        <div class="row">
            <?php
            // Fetch all advertised internships
            $sql = "SELECT * FROM internships";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Display each internship in a floating card style
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <div class="col-md-4">
                        <div class="internship-card">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($row['category']) . ' Internship'; ?></h5>
                                <h6 class="card-subtitle mb-2 text-muted"><?php echo htmlspecialchars($row['nameOfCompany']); ?></h6>
                                <p class="card-text"><strong>Posted On:</strong> <?php echo htmlspecialchars($row['postedOn']); ?></p>
                                <p class="card-text"><strong>Apply By:</strong> <?php echo htmlspecialchars($row['applyBy']); ?></p>
                                <p class="card-text"><?php echo htmlspecialchars($row['aboutInternship']); ?></p>
                                <p class="card-text"><strong>Location:</strong> <?php echo htmlspecialchars($row['location']); ?></p>
                                <p class="card-text"><strong>Perks:</strong> <?php echo htmlspecialchars($row['perks']); ?></p>
                                <p class="card-text"><strong>Duration:</strong> <?php echo htmlspecialchars($row['duration']) . ' weeks'; ?></p>
                                <p class="card-text"><strong>Stipend:</strong> ksh<?php echo htmlspecialchars($row['stipend']) . ' per month'; ?></p>
                                <p class="card-text"><strong>Positions Available:</strong> <?php echo htmlspecialchars($row['positions']); ?></p>

                                <?php
                                // Check if a student is logged in
                                if (isset($_SESSION['student_id'])) {
                                    // If logged in, show apply button
                                    echo '<a href="apply.php?int_id=' . $row['id'] . '" class="btn btn-apply">Apply</a>';
                                } else {
                                    // If not logged in, show login link
                                    echo '<p><a href="student">Log in</a> to apply for this internship.</p>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo '<p class="col">No internships advertised yet.</p>';
            }

            $conn->close();
            ?>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    >
</body>
</html>
