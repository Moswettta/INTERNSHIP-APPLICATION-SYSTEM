<?php
$db = new mysqli('localhost', 'root', '', 'internship');

if ($db->connect_error) {
    die("Database connection failed: " . $db->connect_error);
}

// Optional: Set charset to UTF-8 (adjust as per your database configuration)
$db->set_charset("utf8");

// Optionally, define BASEURL if used in your application
define('BASEURL', '/path/to/your/application/'); // Adjust path as needed
?>
