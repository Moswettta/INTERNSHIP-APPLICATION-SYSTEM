-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 27, 2024 at 10:22 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `internship`
--

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

CREATE TABLE `applications` (
  `id` int(11) NOT NULL,
  `stu_id` int(11) NOT NULL,
  `int_id` int(11) NOT NULL,
  `applied` int(11) NOT NULL DEFAULT 0,
  `status` enum('pending','approved','declined') DEFAULT 'pending',
  `applicationDate` varchar(20) NOT NULL,
  `feedback` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `applications`
--

INSERT INTO `applications` (`id`, `stu_id`, `int_id`, `applied`, `status`, `applicationDate`, `feedback`) VALUES
(1, 1, 1, 1, 'pending', '', ''),
(2, 1, 2, 1, 'pending', '', ''),
(3, 2, 1, 1, 'pending', '', ''),
(4, 2, 2, 1, 'pending', '', ''),
(5, 3, 1, 1, 'pending', '', ''),
(6, 3, 2, 1, 'pending', '', ''),
(7, 4, 3, 1, 'approved', '', ''),
(8, 5, 3, 1, 'approved', '', ''),
(9, 4, 4, 1, 'declined', '', ''),
(10, 4, 5, 1, 'declined', '', ''),
(11, 4, 5, 1, 'declined', '', ''),
(12, 4, 5, 1, 'declined', '', ''),
(21, 4, 6, 1, 'pending', '', ''),
(22, 0, 6, 1, 'pending', '', ''),
(25, 1, 8, 1, 'approved', '', ''),
(26, 2, 8, 1, 'approved', '', ''),
(28, 5, 9, 0, 'approved', '2024-12-21', ''),
(29, 5, 10, 0, 'declined', '2024-12-21', 'yuiyuiytuy'),
(30, 5, 11, 0, 'approved', '2024-12-24', '');

-- --------------------------------------------------------

--
-- Table structure for table `employer`
--

CREATE TABLE `employer` (
  `id` int(11) NOT NULL,
  `nameOfCompany` text NOT NULL,
  `aboutCompany` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address1` text NOT NULL,
  `address2` text NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `zipcode` int(100) NOT NULL,
  `phone` text NOT NULL,
  `country` varchar(100) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `emp_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `employer`
--

INSERT INTO `employer` (`id`, `nameOfCompany`, `aboutCompany`, `email`, `password`, `address1`, `address2`, `city`, `state`, `zipcode`, `phone`, `country`, `ip`, `date`, `emp_id`) VALUES
(5, 'student', 'it', 'abu@gmail.com', '$2y$10$LFgLB7FfJLfzqOQt/FDhuOKexvJOfAYlIQ5GlYMeZQz2Ta8XvDHgu', '6566-00300', 'nairobi', 'Nairobi', 'Not Specified', 300, '0798458270', 'Kenya', '::1', '2024-06-24 11:11:55', 0),
(6, 'Benja', 'ben io', 'ben@gmail.com', '$2y$10$AKSkNOXiSQK/qBB7ileKB.5SfIpvxgIwVUTlPzt0j3pb0GgOQfyPu', '6566-00100', '', 'Nairobi', 'Not Specified', 100, '0798458270', 'Kenya', '::1', '2024-06-24 11:13:39', 0);

-- --------------------------------------------------------

--
-- Table structure for table `internships`
--

CREATE TABLE `internships` (
  `id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `category` text NOT NULL,
  `postedOn` text NOT NULL,
  `applyBy` text NOT NULL,
  `nameOfCompany` text NOT NULL,
  `aboutCompany` text NOT NULL,
  `aboutInternship` text NOT NULL,
  `location` text NOT NULL,
  `perks` text NOT NULL,
  `duration` int(100) NOT NULL,
  `stipend` int(100) NOT NULL,
  `positions` int(11) NOT NULL,
  `whoCanApply` text NOT NULL,
  `featured` tinyint(4) NOT NULL DEFAULT 0,
  `deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `internships`
--

INSERT INTO `internships` (`id`, `emp_id`, `category`, `postedOn`, `applyBy`, `nameOfCompany`, `aboutCompany`, `aboutInternship`, `location`, `perks`, `duration`, `stipend`, `positions`, `whoCanApply`, `featured`, `deleted`) VALUES
(8, 5, 'teacher', '2024-06-24', '2024-06-25', 'student', 'it', 'ict intern', 'Nairobi', 'u', 5, 555554, 1, '0', 1, 0),
(9, 6, 'WATER OUTAGE', '2024-12-21', '2024-12-21', 'Benja', 'ben io', 'e', 'Nairobi', '2222', 8, 666, 7, '0', 0, 0),
(10, 6, 'ICT TEACHING INTERNSHIP', '2024-12-21', '2024-12-21', 'Benja', 'ben io', 'n', 'WESTLANDS', '5000', 5, 2000, 9, '0', 0, 0),
(11, 6, 'ICT TEACHING INTERNSHIP', '2024-12-24', '2024-12-27', 'Benja', 'ben io', 'yutyut', 'y', 'rt', 5, 8, 9, '0', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `stu_id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address1` text NOT NULL,
  `address2` text NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `zipcode` int(100) NOT NULL,
  `phone` text NOT NULL,
  `country` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`stu_id`, `fullname`, `email`, `password`, `address1`, `address2`, `city`, `state`, `zipcode`, `phone`, `country`) VALUES
(2, 'abu', 'abu@gmail.com', 'abu', '30257', '', 'Nairobi', 'kisumu', 100, '0203312147', 'Kenya');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `permission` varchar(255) NOT NULL,
  `join_date` datetime NOT NULL DEFAULT current_timestamp(),
  `last_login` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password`, `permission`, `join_date`, `last_login`) VALUES
(1, 'Sumeet Sharma', 'sksksharma0@gmail.com', 'password', 'admin,editor', '2018-10-06 01:00:34', '2018-10-03 09:12:14'),
(2, 'admin', 'admin@gmail.com', '$2y$10$RJ1.Al8R5uu/5lBO.MKHae9ws25FZnmUIH7Ggf9f6tkloQXW//X.G', 'user', '2024-06-24 12:41:10', '2024-06-24 12:57:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applications`
--
ALTER TABLE `applications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `stu_id` (`stu_id`);

--
-- Indexes for table `employer`
--
ALTER TABLE `employer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `emp_id` (`emp_id`);

--
-- Indexes for table `internships`
--
ALTER TABLE `internships`
  ADD PRIMARY KEY (`id`),
  ADD KEY `emp_id` (`emp_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`stu_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applications`
--
ALTER TABLE `applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `employer`
--
ALTER TABLE `employer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `internships`
--
ALTER TABLE `internships`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `stu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
