<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "internship";

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();

include 'includes/header.php'; // Include your header file

// Check if delete request is sent
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    $sql_delete = "DELETE FROM applications WHERE id = $delete_id";
    mysqli_query($conn, $sql_delete);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Internship Applications</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #eef2f3, #8e9eab);
            margin: 0;
            padding: 0;
        }
        .container {
            margin: 50px auto;
            max-width: 800px;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        h3 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .table th, .table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        .table th {
            background: #007bff;
            color: #fff;
        }
        .table tr:nth-child(even) {
            background: #f2f2f2;
        }
        .table tr:hover {
            background: #d0e4f5;
        }
        .btn {
            display: inline-block;
            padding: 8px 12px;
            font-size: 14px;
            color: #fff;
            background: #dc3545;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        .btn:hover {
            background: #c82333;
        }
        .message {
            text-align: center;
            font-size: 16px;
            margin-top: 20px;
        }
        .message a {
            color: #007bff;
            text-decoration: none;
        }
        .message a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <?php
    if (isset($_SESSION['email'])) {
        $email = $_SESSION['email'];
        $sqlstu = "SELECT * FROM student WHERE email = '$email'";
        $result = mysqli_query($conn, $sqlstu);
        $row_pro = mysqli_fetch_assoc($result);
        $stu_id = $row_pro['stu_id'];

        $sqlapp = "SELECT a.*, i.category, i.location, i.nameOfCompany, i.applyBy
                   FROM applications a
                   INNER JOIN internships i ON a.int_id = i.id
                   WHERE a.stu_id = '$stu_id'";
        $applications = mysqli_query($conn, $sqlapp);

        if (mysqli_num_rows($applications) > 0) {
            ?>
            <h3>Your Internship Applications</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Company Name</th>
                        <th>Internship Category</th>
                        <th>Location</th>
                        <th>Application Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($application = mysqli_fetch_assoc($applications)) {
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($application['nameOfCompany']); ?></td>
                            <td><?= htmlspecialchars($application['category']); ?></td>
                            <td><?= htmlspecialchars($application['location']); ?></td>
                            <td><?= htmlspecialchars($application['applicationDate']); ?></td>
                            <td><?= htmlspecialchars($application['status']); ?></td>
                            <td>
                                <a href="?delete=<?= $application['id']; ?>" class="btn" onclick="return confirm('Are you sure you want to delete this application?')">Delete</a>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
            <?php
        } else {
            echo "<p class='message'>No internship applications found.</p>";
        }
    } else {
        echo "<p class='message'>Please <a href='login.php'>login</a> to view internship applications.</p>";
    }
    ?>
</div>

<?php include 'includes/footer.php'; // Include your footer file ?>

</body>
</html>
