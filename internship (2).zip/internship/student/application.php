<?php
// Define a basic sanitize function for integer inputs
function sanitize($input) {
    return filter_var($input, FILTER_SANITIZE_NUMBER_INT);
}

session_start();

// Database connection details
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'internship';

// Create connection
$db = new mysqli($host, $username, $password, $database);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Check if the student is logged in
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit;
} else {
    $email = $_SESSION['email'];
    $sqlstu = "SELECT * FROM student WHERE email = '$email'";
    $result = $db->query($sqlstu);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $stu_id = $row['stu_id'];

        // Assuming $_GET['apply'] contains the internship ID
        if (isset($_GET['apply'])) {
            $int_id = sanitize($_GET['apply']); // Sanitize the input
            
            // Insert application into database
            $sqlInsert = "INSERT INTO applications (stu_id, int_id, applicationDate)
                          VALUES (?, ?, CURRENT_DATE)";
            
            $stmt = $db->prepare($sqlInsert);
            if ($stmt) {
                $stmt->bind_param("ii", $stu_id, $int_id);
                $stmt->execute();
                
                // Check if application was successfully inserted
                if ($stmt->affected_rows > 0) {
                    // Application successfully applied
                    header("Location: myaccount.php");
                    exit;
                } else {
                    // Error handling if application insert fails
                    echo "Failed to apply for internship.";
                }
            } else {
                // Error handling for prepare error
                echo "Prepare statement error: " . $db->error;
            }
        } else {
            echo "Internship ID is missing.";
        }
    } else {
        echo "Student details not found.";
    }
}
?>
