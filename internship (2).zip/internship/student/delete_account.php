<?php
error_reporting(0);

// Start the session
session_start();

// Database connection
$servername = "localhost";
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "internship"; // Your database name

// Create connection
$db = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Include header
include('includes/header.php');
?>

<div class="container-fluid p-2">
    <div class="card">
        <div class="card-header">
            <h3 class="h3-responsive p-2 text-center">Delete Account?</h3>
        </div>
        <div class="card-body">
            <div class="container-fluid">
                <div class="">
                    <p class="lead text-center">You won't be able to reap the benefits of offers and discounts on our products anymore. Do you really want to delete your account?</p>
                </div>
                <form class="p-3 grey-text" method="post" action="" enctype="multipart/form-data">
                    <div class="text-center mt-4 float-left">
                        <button class="btn btn-danger" type="submit" name="yes" style="background: #607d8b">Yes, I do</button>
                    </div>
                    <div class="text-center mt-4 float-right">
                        <button class="btn btn-success" type="submit" name="no" style="background: #607d8b">No, I don't</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
// Check if the form is submitted
if (isset($_POST['yes'])) {
    // Check if email is set in the session
    if (isset($_SESSION['email']) && !empty($_SESSION['email'])) {
        $email = $_SESSION['email'];

        // Prepare and execute the delete statement
        $delete_student = $db->prepare("DELETE FROM student WHERE email = ?");
        $delete_student->bind_param("s", $email);

        if ($delete_student->execute()) {
            if ($delete_student->affected_rows > 0) {
                echo "<script>alert('Your account has been deleted successfully!')</script>";
                echo "<script>window.open('index.php', '_self')</script>";
            } else {
                echo "<script>alert('No account found with the provided email.')</script>";
            }
        } else {
            echo "<script>alert('Failed to delete your account. Please try again.')</script>";
        }
    } else {
        echo "<script>alert('No email found in the session data.')</script>";
    }
}

if (isset($_POST['no'])) {
    echo "<script>alert('We are glad you are with us!')</script>";
    echo "<script>window.open('myaccount.php', '_self')</script>";
}

// Include footer
include('includes/footer.php');
?>
