<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "internship";

// Create connection
$db = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

session_start();
error_reporting(0);

include 'includes/header.php';

// Fetch student details
$email = $_SESSION['email'];
$sql = "SELECT * FROM student WHERE email = '$email'";
$result = $db->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while ($row_pro = $result->fetch_assoc()) {
        $stu_id = $row_pro['stu_id'];
        $cus_name = $row_pro['fullname'];
        $cus_email = $row_pro['email'];
        $cus_address1 = $row_pro['address1'];
        $cus_address2 = $row_pro['address2'];
        $cus_city = $row_pro['city'];
        $cus_state = $row_pro['state'];
        $cus_zipcode = $row_pro['zipcode'];
        $cus_phone = $row_pro['phone'];
        $cus_country = $row_pro['country'];
    }
} else {
    echo "No student found with this email.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Account</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .container-fluid {
            max-width: 800px;
            margin: 20px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background-color: #007bff;
            color: #fff;
            text-align: center;
            padding: 15px;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }
        .card-body {
            padding: 20px;
        }
        .form-sm {
            margin-bottom: 15px;
        }
        .form-sm label {
            font-weight: bold;
            color: #333;
            display: block;
            margin-bottom: 5px;
        }
        .form-sm input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .btn {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .text-center {
            text-align: center;
        }
    </style>
</head>
<body>
<div class="container-fluid p-2">
    <div class="card">
        <div class="card-header">
            <h3 class="h3-responsive p-2 text-center">Edit Account</h3>
        </div>
        <div class="card-body">
            <div class="container-fluid">
                <form class="p-3 grey-text" method="post" action="" enctype="multipart/form-data">
                    <div class="row">                    
                        <div class="col-md-6">
                            <div class="md-form form-sm"> <i class="fa fa-user prefix"></i>
                              <label for="fullname">Full Name</label>
                              <input type="text" id="fullname" class="form-control form-control-sm" name="fullname" value="<?php echo $cus_name; ?>">
                            </div>
                            <div class="md-form form-sm"> <i class="fa fa-envelope prefix"></i>
                              <label for="email">Email</label>
                              <input type="email" id="email" class="form-control form-control-sm" name="email" value="<?php echo $cus_email; ?>">
                            </div>
                            <div class="md-form form-sm"> <i class="fa fa-map prefix"></i>
                              <label for="address1">Address Line 1</label>
                              <input type="text" id="address1" class="form-control form-control-sm" name="address1" value="<?php echo $cus_address1; ?>">
                            </div>
                            <div class="md-form form-sm"> <i class="fa fa-map-marker prefix"></i>
                              <label for="address2">Address Line 2</label>
                              <input type="text" id="address2" class="form-control form-control-sm" name="address2" value="<?php echo $cus_address2; ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="md-form form-sm"> <i class="fa fa-map-marker prefix"></i>
                              <label for="city">City</label>
                              <input type="text" id="city" class="form-control form-control-sm" name="city" value="<?php echo $cus_city; ?>">
                            </div>
                            <div class="md-form form-sm"> <i class="fa fa-map-marker prefix"></i>
                              <label for="state">State</label>
                              <input type="text" id="state" class="form-control form-control-sm" name="state" value="<?php echo $cus_state; ?>">
                            </div>
                            <div class="md-form form-sm"> <i class="fa fa-map-marker prefix"></i>
                              <label for="zipcode">Zipcode</label>
                              <input type="text" id="zipcode" class="form-control form-control-sm" name="zipcode" value="<?php echo $cus_zipcode; ?>">
                            </div>
                            <div class="md-form form-sm"> <i class="fa fa-phone prefix"></i>
                              <label for="phone">Phone</label>
                              <input type="text" id="phone" class="form-control form-control-sm" name="phone" value="<?php echo $cus_phone; ?>">
                            </div>
                            <div class="md-form form-sm"> <i class="fa fa-map-marker prefix"></i>
                              <label for="country">Country</label>
                              <input type="text" id="country" class="form-control form-control-sm" name="country" value="<?php echo $cus_country; ?>">
                            </div>
                        </div>
                        <div class="text-center mt-4">
                            <button class="btn btn-default" type="submit" name="update">Update <i class="fa fa-paper-plane-o ml-1"></i></button>
                        </div>                  
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
if (isset($_POST['update'])) {
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $address1 = $_POST['address1'];
    $address2 = $_POST['address2'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $zipcode = $_POST['zipcode'];
    $phone = $_POST['phone'];
    $country = $_POST['country'];

    $updatestu = "UPDATE student SET fullname = '$fullname', email = '$email', address1 = '$address1', address2 = '$address2', city = '$city', state = '$state', zipcode = '$zipcode', phone = '$phone', country = '$country' WHERE stu_id = '$stu_id'";
    $run_query = $db->query($updatestu);
    if ($run_query) {
        echo "<script>alert('Your account has been successfully updated')</script>";
        echo "<script>window.open('myaccount.php','_self')</script>";
    } else {
        echo "Error updating record: " . $db->error;
    }
}

$db->close();
?>
</body>
</html>
