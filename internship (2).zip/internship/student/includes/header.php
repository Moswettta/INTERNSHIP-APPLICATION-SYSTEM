<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Assignment</title>
  <!-- Font Awesome for icons -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  <style>
    /* General styles */
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f0f0f0;
    }
    
    /* Header styles */
    header {
      background-color: black;
      padding: 10px 0;
      color: white;
      text-align: center;
    }

    /* Navbar styles */
    nav {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 20px;
      background-color: #333;
    }

    nav a {
      color: white;
      text-decoration: none;
      margin: 0 10px;
    }

    nav a:hover {
      text-decoration: underline;
    }

    .navbar-brand {
      font-size: 1.5em;
      font-weight: bold;
    }

    .nav-flex-icons {
      display: flex;
      align-items: center;
    }

    .nav-flex-icons a {
      margin-left: 10px;
    }
  </style>
</head>
<body>
  
  <nav>
   
    <div>
      <a href="myaccount.php">Home</a><br>
    </div>
    <div class="nav-flex-icons">
      <a href="/internship/index.php">LOG OUT</a>
      
    </div>
  </nav>
</body>
</html>
