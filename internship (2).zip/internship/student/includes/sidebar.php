<!-- Sidebar -->
<nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
  <div class="position-sticky">
    <ul class="nav flex-column">
      <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="myaccount.php">
          Home
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="myaccount.php">
          Profile
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="Internships.php">
          Internships
        </a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="VEIW.php">
          Veiw My Applications
        </a>
      </li>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="logout.php">
          Logout
        </a>
      </li>
    </ul>
  </div>
</nav>

<style>
#sidebar {
  height: 100%;
}

#sidebar .nav-link {
  padding: 10px 15px;
  text-decoration: none;
  color: #333;
}

#sidebar .nav-link:hover {
  background-color: navyblue;
}

#sidebar .nav-link.active {
  background-color: #007bff;
  color: #fff;
}

#sidebar .nav-link.active:hover {
  background-color: #007bff;
}
</style>
