<?php
    session_start();
    include 'C:/xampp/htdocs/internship/includes/header.php';
    include 'C:/xampp/htdocs/internship/config.php';
?>

<div class="container p-3">
    <div class="card">
        <div class="card-header">
            <h3 class="p-2 h3-responsive">Login here!</h3>
        </div>
        <form action="" method="post">
            <div class="card-body">
                <div class="md-form form-sm">
                    <input type="text" id="email" class="form-control form-control-sm" name="email" required>
                    <label for="email">Email</label>
                </div>
                <div class="md-form form-sm">
                    <input type="password" id="password" class="form-control form-control-sm" name="password" required>
                    <label for="password">Password</label>
                </div>
                <div class="p-3">
                    <div class="float-left">
                        <p class="">Forgot your password? <a href="checkout.php?forgot_pass">Click here</a></p>
                    </div>
                    <div class="float-right">
                        <p class="">Don't have an account? <a href="register.php">Register now</a></p>
                    </div>
                </div>
            </div>            
            <div class="card-footer">
                <div class="float-right">
                    <button type="submit" name="login" class="btn btn-black" style="border-radius: 10em;background: #1c2a48">Login</button>
                </div>
            </div>
            <a href="internship/index.php">Home
        </form>
        
        <?php
    // Database connection settings
    $db_host = 'localhost';
    $db_user = 'root';
    $db_password = '';
    $db_name = 'internship';

    // Create connection
    $db = new mysqli($db_host, $db_user, $db_password, $db_name);

    // Check connection
    if ($db->connect_error) {
        die("Connection failed: " . $db->connect_error);
    }
            if(isset($_POST['login'])){
                $email = $_POST['email'];
                $password = $_POST['password'];

                // Correct the SQL query here (remove single quotes around table name)
                $sql = "SELECT * FROM student WHERE password = '$password' AND email = '$email'";
                $runSql = $db->query($sql);

                // Check if the query executed successfully
                if($runSql){
                    $check_student = mysqli_num_rows($runSql);
                    if($check_student == 0){
                        echo "<script>alert('Your password or email is incorrect, please try again!')</script>";
                        exit();
                    }
                                    
                    if($check_student > 0){
                        $_SESSION['email'] = $email;
                        echo "<script>alert('You logged in successfully!')</script>";
                        echo "<script>window.open('myaccount.php','_self')</script>";
                    }else{
                        $_SESSION['email'] = $email;
                        echo "<script>alert('You logged in successfully!')</script>";
                        echo "<script>window.open('cart.php','_self')</script>";
                    }
                } else {
                    echo "<script>alert('Error executing SQL query: " . $db->error . "')</script>";
                }
            }
        ?>
    </div>
</div>

<?php
    include 'includes/footer.php';
?>
