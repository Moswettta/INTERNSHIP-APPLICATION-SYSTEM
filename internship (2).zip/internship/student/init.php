<?php

// Define the CART_COOKIE constant with a value
define('CART_COOKIE', 'your_cookie_name_here');

// Database connection
$db = mysqli_connect('localhost', 'root', '', 'internship');
if(mysqli_connect_errno()){
    echo "Database connection failed with following errors: ".mysqli_connect_error();
    die();
}

// Include necessary files
require_once $_SERVER['DOCUMENT_ROOT'].'/internship/config.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/internship/helpers/helpers.php';




?>

