<?php
// Database connection details
$host = 'localhost'; // Change this to your host
$username = 'root'; // Change this to your username
$password = ''; // Change this to your password
$database = 'internship'; // Change this to your database name

// Create connection
$db = new mysqli($host, $username, $password, $database);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

session_start();
include 'includes/header.php';

// Sanitize function
function sanitize($input) {
    global $db; // Assuming $db is your database connection object
    return mysqli_real_escape_string($db, htmlspecialchars(strip_tags(trim($input))));
}

// Fetch the internship details
if(isset($_GET['internship'])){
    $id = sanitize((int)$_GET['internship']);
    $sql = "SELECT * FROM internships WHERE id = '$id'";
    $sqlResult = $db->query($sql);
    $internshipCount = mysqli_num_rows($sqlResult);
    if($internshipCount > 0){
        while ($row = mysqli_fetch_array($sqlResult)) {
            $category = $row['category'];
            $nameOfCompany = $row['nameOfCompany'];
            $postedOn = $row['postedOn'];
            $applyBy = $row['applyBy'];
            $aboutCompany = $row['aboutCompany'];
            $aboutInternship = $row['aboutInternship'];
            $location = $row['location'];
            $perks = $row['perks'];
            $duration = $row['duration'];
            $stipend = $row['stipend'];
            $positions = $row['positions'];
            $whoCanApply = $row['whoCanApply'];
        }
    } else {
        echo "Internship does not exist";
        exit();
    }
} else {
    echo "Data is missing, please select the internship";
    exit();
}

// Function to get application date for the current student and internship
function getApplicationDate($db, $stu_id, $int_id) {
    $sql = "SELECT applicationDate FROM applications WHERE stu_id = '$stu_id' AND int_id = '$int_id'";
    $result = $db->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['applicationDate'];
    }
    return null;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?=$category;?> Internship</title>
    <style>
        /* General styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }

        /* Container styles */
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        /* Card styles */
        .card {
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .card-header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }

        .card-body {
            padding: 20px;
        }

        .card-footer {
            background-color: #f9f9f9;
            padding: 10px;
            border-top: 1px solid #ddd;
        }

        /* Table styles */
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .table th, .table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        .table th {
            background-color: #f4f4f4;
        }

        /* Button styles */
        .btn {
            display: inline-block;
            padding: 10px 15px;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            text-align: center;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        /* Form styles */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h2><?=$category;?> Internship in <?=$location;?> at <?=$nameOfCompany;?></h2>
        </div>
        <div class="card-body">
            <h4><?=$category;?></h4>
            <h5><b>Location: </b><?=$location;?></h5>
            <table class="table">
                <thead>
                    <tr>
                        <th>Duration</th>
                        <th>Stipend</th>
                        <th>Posted On</th>
                        <th>Apply By</th>
                        <th>Available Positions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?=$duration;?> months</td>
                        <td><?=$stipend;?></td>
                        <td><?=$postedOn;?></td>
                        <td><?=$applyBy;?></td>
                        <td><?=$positions;?></td>
                    </tr>
                </tbody>
            </table>
            <div>
                <div>
                    <h4>About Company</h4>
                    <p><?=$aboutCompany;?></p>
                </div>
                <div>
                    <h4>About Internship</h4>
                    <p><?=nl2br($aboutInternship);?></p>
                </div>
                <div>
                    <h4>No. of positions available</h4>
                    <p><?=$positions;?></p>
                </div>
                <div>
                    <h4>Who can apply</h4>
                    <p><?=nl2br($whoCanApply);?></p>
                </div>
                <div>
                    <h4>Perks of the internship</h4>
                    <p><?=$perks;?></p>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <form action="process_application.php" method="POST">
                <div class="form-group">
                    <label for="applicationDate">Application Date:</label>
                    <input type="date" id="applicationDate" name="applicationDate" required>
                </div>
                <input type="hidden" name="internshipId" value="<?= $id; ?>">
                <?php
                if(!isset($_SESSION['email'])){
                    echo "<a href='login.php' class='btn' name='apply'>Apply Now</a>";
                } else {
                    $email = $_SESSION['email'];
                    $sqlstu = "SELECT * FROM student WHERE email = '$email'";
                    $result = $db->query($sqlstu);
                    while ($row_pro = mysqli_fetch_array($result)) {
                        $stu_id = $row_pro['stu_id'];
                    }

                    $sqlapp = "SELECT * FROM applications WHERE stu_id = '$stu_id' AND int_id = '$id'";
                    $applications = $db->query($sqlapp);
                    if(mysqli_num_rows($applications) > 0){
                        $applicationDate = getApplicationDate($db, $stu_id, $id);
                        if ($applicationDate) {
                            echo "<a href='#' class='btn' name='applied'>Applied on $applicationDate</a>";
                        } else {
                            echo "<a href='#' class='btn' name='applied'>Applied</a>";
                        }
                    } else {
                        echo "<button type='submit' class='btn' name='apply'>Apply Now</button>";
                    }
                }
                ?>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php';?>
</body>
</html>
