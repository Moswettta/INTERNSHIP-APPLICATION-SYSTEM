<?php
session_start();
include 'C:/xampp/htdocs/internship/config.php';
include 'includes/header.php';

$sql = "SELECT * FROM internships WHERE deleted=0";
$internships = $db->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Internships</title>
    <style>
        .internships-page {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: grey;
        }

        .internships-container {
            width: 90%;
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .internships-row {
            display: flex;
            flex-wrap: wrap;
        }

        .internships-col {
            flex: 1;
            margin: 10px;
        }

        .internship-card {
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 20px;
            background-color: orange;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .internship-card-header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }

        .internship-card-body {
            padding: 20px;
        }

        .internship-card-footer {
            background-color: #f9f9f9;
            padding: 10px;
            border-top: 1px solid #ddd;
            text-align: center;
        }

        .internship-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .internship-table th, .internship-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        .internship-table th {
            background-color: #f4f4f4;
        }

        .internship-btn {
            display: inline-block;
            padding: 10px 15px;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            text-decoration: none;
        }

        .internship-btn:hover {
            background-color: #0056b3;
        }

        .internships-title {
            text-align: center;
            padding: 10px;
        }

        .float-left {
            float: left;
        }

        .float-right {
            float: right;
        }

        .p-2 {
            padding: 10px;
        }

        .ms-sm-auto {
            margin-left: auto;
        }

        .px-md-4 {
            padding: 0 1.5rem;
        }
    </style>
</head>
<body class="internships-page">
<main>
  <div class="internships-container">
    <div class="internships-row">
      <!-- Sidebar -->
      <div class="internships-col ms-sm-auto col-lg-10 px-md-4">
        <h3 class="internships-title">List of Internships</h3>
        <div class="internships-row">
          <!-- List of Internships -->
          <?php while ($internship = mysqli_fetch_assoc($internships)) : ?>
            <div class="internships-col">
              <div class="internship-card">
                <div class="internship-card-header">
                  <h2 class="p-2 text-center card-title"><?= $internship['nameOfCompany']; ?></h2>
                </div>
                <div class="internship-card-body">
                  <h4 class="p-2 h4-responsive float-left"><?= $internship['category']; ?></h4>
                  <h5 class="p-2 h5-responsive float-right"><b>Location: </b><?= $internship['location']; ?></h5>
                  <table class="internship-table table-bordered">
                    <thead>
                      <tr>
                        <th>Duration</th>
                        <th>Stipend</th>
                        <th>Posted On</th>
                        <th>Apply By</th>
                        <th>Available Positions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><?= $internship['duration']; ?> months</td>
                        <td>ksh <?= $internship['stipend']; ?></td>
                        <td><?= $internship['postedOn']; ?></td>
                        <td><?= $internship['applyBy']; ?></td>
                        <td><?= $internship['positions']; ?></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div class="internship-card-footer">
                  <a href="internship.php?internship=<?= $internship['id']; ?>" class="internship-btn">View Details</a>
                </div>
              </div>
            </div>
          <?php endwhile; ?>
        </div>
        <br>
      </div>
    </div>
  </div>
</main>

<?php include 'includes/footer.php'; ?>
</body>
</html>
