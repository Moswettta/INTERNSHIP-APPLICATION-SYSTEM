<?php
session_start();

// Database connection
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'internship';

$db = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check the connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit;
} else {
    $email = $_SESSION['email'];
    // Fetch user details
    $userDetails = getUserDetails($db, $email);

    // Fetch applied internships
    $applications = getAppliedInternships($db, $userDetails['stu_id']);
}

// Functions to fetch user details and applied internships
function getUserDetails($db, $email) {
    $sql = "SELECT * FROM student WHERE email = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

function getAppliedInternships($db, $userId) {
    $sql = "SELECT i.nameOfCompany, i.aboutInternship AS position, a.status 
            FROM applications a
            JOIN internships i ON a.int_id = i.id
            WHERE a.stu_id = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Account</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">  
  
  <style>
    /* Internal CSS styles */
    body {
      background-color: #f5f5f5; /* Light grey background */
      color: #333; /* Dark text color */
    }
    
    .h3-responsive {
      font-size: 1.75rem;
      font-weight: 400;
      color: red; /* Dark text color */
    }
    
    .card {
      margin-bottom: 20px;
      background-color: #fff; /* White background */
      border: 1px solid #ddd; /* Light border */
      border-radius: 8px; /* Rounded corners */
      box-shadow: 0 2px 4px rgba(0,0,0,0.1); /* Shadow for depth */
    }
    
    .table {
      width: 100%;
      margin-bottom: 1rem;
      background-color: transparent;
      display: table;
      border-collapse: collapse; /* Collapse borders */
    }
    
    .table th, .table td {
      padding: 8px; /* Padding for cells */
      text-align: left; /* Align text left */
      vertical-align: top; /* Align text top */
      color: #555; /* Slightly lighter text color */
    }
    
    .table-striped tbody tr:nth-of-type(odd) {
      background-color: #f8f9fa; /* Light grey striping */
    }
    
    .navbar-dark .navbar-brand, .navbar-dark .navbar-nav .nav-link {
      color: #fff; /* White text color for navbar links */
    }
    
    .navbar-dark .navbar-toggler-icon {
      border-color: rgba(255, 255, 255, 0.5); /* White border color for toggler icon */
    }
    
    .navbar-nav .nav-link {
      padding: 10px 20px;
      color: #fff;
      transition: background-color 0.3s ease-in-out;
    }
    
    .navbar-nav .nav-link:hover {
      background-color: #007bff; /* Blue background on hover */
      color: #fff;
    }
    
    .card-header {
      background-color: #007bff; /* Blue background for header */
      color: #fff; /* White text color */
    }
    
    .table-responsive {
      margin-top: 20px;
    }
    
    .nav-item .nav-link.active {
      background-color: #0056b3; /* Darker blue for active link */
    }
  </style>
</head>
<body>

<?php include 'includes/header.php'; ?>

<div class="container-fluid">
  <div class="row">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
  
    <!-- Main Content -->
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <nav class="mb-1 navbar navbar-expand-lg navbar-dark default-color">
          <a class="navbar-brand" href="myaccount.php"><?= $userDetails['fullname']; ?></a>
          <!-- Collapse button -->
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav"
          aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
          </button>
          <!-- Collapsible content -->
          <div class="collapse navbar-collapse" id="basicExampleNav">
            <!-- Links -->
            <ul class="navbar-nav mr-auto smooth-scroll">
                <li class="nav-item">
                  <a class="nav-link" href="/internship/student/edit_account.php?edit_account">Edit Account</a>
                </li>
                <li class="nav-item">
                 <a class="nav-link" href="/internship/student/change_password.php">Change Password</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/internship/student/delete_account.php">Delete Account</a>
                </li>
            </ul>
          </div>
      </nav>

      <div class='card'>
        <div class='card-header'>
          <h3 class='h3-responsive p-2'>Hello <?= $userDetails['fullname']; ?></h3>
        </div>
        <div class='card-body table-responsive'>
          <table class='table table-striped table-condensed' style='display: table'>
            <tr>
              <th><b>Name: </b></th>
              <td><?= $userDetails['fullname']; ?></td>
            </tr>
            <tr>
              <th><b>Phone: </b></th>
              <td><?= $userDetails['phone']; ?></td>
            </tr>
            <tr>
              <th><b>Email: </b></th>
              <td><?= $userDetails['email']; ?></td>
            </tr>
            <tr>
              <th><b>Address: </b></th>
              <td><?= $userDetails['address1'] . ', ' . $userDetails['address2']; ?></td>
            </tr>
            <tr>
              <th><b>City: </b></th>
              <td><?= $userDetails['city']; ?></td>
            </tr>
            <tr>
              <th><b>State: </b></th>
              <td><?= $userDetails['state']; ?></td>
            </tr>
            <tr>
              <th><b>Zipcode: </b></th>
              <td><?= $userDetails['zipcode']; ?></td>
            </tr>
          </table>
        </div>
      </div>
           
    </main>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
</body>
</html>
