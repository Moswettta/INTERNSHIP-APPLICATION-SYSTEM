<?php
// Database connection details
$host = 'localhost'; // Change this to your host
$username = 'root'; // Change this to your username
$password = ''; // Change this to your password
$database = 'internship'; // Change this to your database name

// Create connection
$db = new mysqli($host, $username, $password, $database);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

session_start();
include 'includes/header.php';
include_once 'init.php'; // Include the initialization file

// Sanitize function
if (!function_exists('sanitize')) {
    function sanitize($input) {
        global $db; // Assuming $db is your database connection object
        return mysqli_real_escape_string($db, htmlspecialchars(strip_tags(trim($input))));
    }
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['apply'])) {
        $applicationDate = sanitize($_POST['applicationDate']);
        $internshipId = isset($_POST['internshipId']) ? sanitize((int)$_POST['internshipId']) : 0;
        $email = $_SESSION['email'];

        // Get student details
        $sqlStu = "SELECT * FROM student WHERE email = '$email'";
        $resultStu = $db->query($sqlStu);
        if ($resultStu && $resultStu->num_rows > 0) {
            $rowStu = $resultStu->fetch_assoc();
            $stu_id = $rowStu['stu_id'];
            $studentName =              $rowStu['fullname']; // Assuming these fields exist in your 'student' table

            // Get internship details
            $sqlInt = "SELECT * FROM internships WHERE id = '$internshipId'";
            $resultInt = $db->query($sqlInt);
            if ($resultInt && $resultInt->num_rows > 0) {
                $rowInt = $resultInt->fetch_assoc();
                $internshipTitle = $rowInt['category']; // Assuming 'category' is the internship title field

                // Check if the application date is valid
                $applyBy = $rowInt['applyBy'];
                if (strtotime($applicationDate) <= strtotime($applyBy)) {
                    // Check if application already exists
                    $sqlCheck = "SELECT * FROM applications WHERE stu_id = '$stu_id' AND int_id = '$internshipId'";
                    $resultCheck = $db->query($sqlCheck);

                    if ($resultCheck->num_rows > 0) {
                        echo "You have already applied to this internship.";
                    } else {
                        // Insert new application
                        $sqlInsert = "INSERT INTO applications (stu_id, int_id, applicationDate) VALUES ('$stu_id', '$internshipId', '$applicationDate')";
                        if ($db->query($sqlInsert) === TRUE) {
                            echo "<div class='alert alert-success' role='alert'>
                                    Congratulations, $studentName! Your application for the '$internshipTitle' internship has been successfully submitted.
                                  </div>";
                        } else {
                            echo "Error: " . $sqlInsert . "<br>" . $db->error;
                        }
                    }
                } else {
                    echo "The application date has passed. You cannot apply for this internship.";
                }
            } else {
                echo "Internship not found.";
            }
        } else {
            echo "Student not found.";
        }
    }
}
?>
