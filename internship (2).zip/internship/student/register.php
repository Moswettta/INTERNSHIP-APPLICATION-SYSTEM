<?php
    // Start session
    session_start();
    
    // Include necessary files
    include('C:/xampp/htdocs/internship/includes/header.php');
    include('config.php'); // Include file for database connection

    // Create database connection
    $db = new mysqli('localhost', 'root', '', 'internship');

    // Check if connection was successful
    if ($db->connect_error) {
        die("Connection failed: " . $db->connect_error);
    }

    // Define sanitize function to prevent SQL injection
    function sanitize($data) {
        global $db;
        return mysqli_real_escape_string($db, trim($data));
    }

    // Check if form is submitted
    if(isset($_POST['submit'])) {
        // Get user input and sanitize it
        $fullname = sanitize($_POST['fullname']);
        $email = sanitize($_POST['email']);
        $password = sanitize($_POST['password']);
        $address1 = sanitize($_POST['address1']);
        $address2 = sanitize($_POST['address2']);
        $city = sanitize($_POST['city']);
        $state = sanitize($_POST['state']);
        $zipcode = sanitize($_POST['zipcode']);
        $phone = sanitize($_POST['phone']);
        $country = sanitize($_POST['country']);

        // Insert user data into the database
        $insertQuery = "INSERT INTO student (fullname, email, password, address1, address2, city, state, zipcode, phone, country) 
                        VALUES ('$fullname', '$email', '$password', '$address1', '$address2', '$city', '$state', '$zipcode', '$phone', '$country')";

        // Execute the query
        $result = $db->query($insertQuery);

        // Check if the query was successful
        if($result) {
            // Set session email
            $_SESSION['email'] = $email;
            
            // Display success message
            echo "<script>alert('Registration successful. Please log in.')</script>";
            
            // Redirect user to login page
            header('Location: index.php');
            exit(); // Exit script to prevent further execution
        } else {
            // Display error message
            echo "<script>alert('Registration failed. Please try again.')</script>";
        }
    }
?>

<!-- HTML Form -->
<div class="container-fluid p-2">
    <div class="card">
        <div class="card-header">
            <h3 class="h3-responsive p-2 text-center">Registration Form</h3>
        </div>
        <div class="card-body">
            <div class="container-fluid">
                <form class="p-3 grey-text" method="post" action="register.php">
                    <div class="row">                    
                        <div class="col-md-6">
                            <!-- Full Name -->
                            <div class="md-form form-sm"> 
                                <i class="fa fa-user prefix"></i>
                                <input type="text" id="fullname" class="form-control form-control-sm" name="fullname">
                                <label for="fullname">Full Name</label>
                            </div>
                            <!-- Email -->
                            <div class="md-form form-sm"> 
                                <i class="fa fa-envelope prefix"></i>
                                <input type="email" id="email" class="form-control form-control-sm" name="email">
                                <label for="email">Email</label>
                            </div>
                            <!-- Password -->
                            <div class="md-form form-sm"> 
                                <i class="fa fa-lock prefix"></i>
                                <input type="password" id="password" class="form-control form-control-sm" name="password">
                                <label for="password">Password</label>
                            </div>
                            <!-- Address 1 -->
                            <div class="md-form form-sm"> 
                                <i class="fas fa-map prefix"></i>
                                <input type="text" id="address1" class="form-control form-control-sm" name="address1">
                                <label for="address1">Address 1</label>
                            </div>
                            <!-- Address 2 -->
                            <div class="md-form form-sm"> 
                                <i class="fa fa-map-marker prefix"></i>
                                <input type="text" id="address2" class="form-control form-control-sm" name="address2">
                                <label for="address2">Address 2</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <!-- City -->
                            <div class="md-form form-sm"> 
                                <i class="fa fa-map-marker-alt prefix"></i>
                                <input type="text" id="city" class="form-control form-control-sm" name="city">
                                <label for="city">City</label>
                            </div>
                            <!-- State -->
                            <div class="md-form form-sm"> 
                                <i class="fa fa-map-marker-alt prefix"></i>
                                <input type="text" id="state" class="form-control form-control-sm" name="state">
                                <label for="state">State</label>
                            </div>
                            <!-- Zipcode -->
                            <div class="md-form form-sm"> 
                                <i class="fa fa-map-marker-alt prefix"></i>
                                <input type="text" id="zipcode" class="form-control form-control-sm" name="zipcode">
                                <label for="zipcode">Zipcode</label>
                            </div>
                            <!-- Phone -->
                            <div class="md-form form-sm"> 
                                <i class="fa fa-phone prefix"></i>
                                <input type="text" id="phone" class="form-control form-control-sm" name="phone">
                                <label for="phone">Phone</label>
                            </div>
                            <!-- Country -->
                            <div class="md-form form-sm"> 
                                <i class="fa fa-map-marker-alt prefix"></i>
                                <input type="text" id="country" class="form-control form-control-sm" name="country" value="India">
                                <label for="country">Country</label>
                            </div>
                        </div>
                        <div class="text-center mt-4">
                            <button class="btn btn-default" type="submit" name="submit">Submit <i class="fa fa-paper-plane-o ml-1"></i></button>
                        </div>                  
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>
